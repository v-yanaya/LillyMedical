﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//TreeNode root = new TreeNode("礼来药品及问答信息列表", null, null, "javascript:void(0)", "_self");
namespace LillyMedical.front
{
    public partial class sitemap : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindSiteMapTree();
            }
        }
        public void BindSiteMapTree()
        {
            List<Model.DBModel.Lilly_TherapeuticAreas> areaList = LillyMedical.Utility.BusinessHelper.GetAllAreas();
            List<Model.DBModel.Lilly_Medicals> medecalList = LillyMedical.Utility.BusinessHelper.GetAllMedecials();
            List<Model.DBModel.Lilly_MedicalQA> medicalQAList = LillyMedical.Utility.BusinessHelper.GetAllMedicalQA();
            List<Model.DBModel.Lilly_Category> categoryList = LillyMedical.Utility.BusinessHelper.GetAllCategory();
            foreach (Model.DBModel.Lilly_TherapeuticAreas area in areaList)
            {
                //领域
                TreeNode areaNode = new TreeNode(area.AreaName, "area", null, "javascript:void(0)", "_self");
                areaNode.Expanded = false;
                foreach (Model.DBModel.Lilly_Medicals medical in medecalList)
                {
                    if (medical.TID == area.ID)
                    {
                        //产品
                        TreeNode medicalNode = new TreeNode(medical.Name, "medical", null, "javascript:void(0)", "_self");
                        medicalNode.Expanded = false;
                        foreach (Model.DBModel.Lilly_Category category in categoryList)
                        {
                            //Category
                            TreeNode categoryNode = new TreeNode(category.Name, null, null, "javascript:void(0)", "_self");
                            categoryNode.Expanded = false;
                            foreach (Model.DBModel.Lilly_MedicalQA qa in medicalQAList)
                            {
                                if (qa.Status && qa.MID == medical.ID && qa.CID == category.ID)
                                {
                                    //问答
                                    string url = HttpContext.Current.Request.Url.ToString();
                                    string newUrl = url.Substring(0, url.IndexOf("/front/")) + "/zh-cn/answer/" + qa.VeevaID.Trim();
                                    TreeNode qaNode = new TreeNode(LillyMedical.Utility.BusinessHelper.FormatTradeMark(qa.Title), null, null, "javascript:window.open('" + newUrl + "');void(0);", "_self");
                                    categoryNode.ChildNodes.Add(qaNode);
                                }
                            }
                            medicalNode.ChildNodes.Add(categoryNode);
                        }
                        areaNode.ChildNodes.Add(medicalNode);
                    }
                }
                treeview.Nodes.Add(areaNode);
            }
        }
    }
}