﻿using LillyMedical.Utility;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace LillyMedical.front
{
    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HtmlHead head = (HtmlHead)Page.Header;
            //title
            HtmlTitle title = new HtmlTitle();
            title.Text = System.Configuration.ConfigurationManager.AppSettings["homepage_title"].ToString();
            head.Controls.Add(title);
            //description
            HtmlMeta description = new HtmlMeta();
            description.Name = "Description";
            description.Content = System.Configuration.ConfigurationManager.AppSettings["homepage_description"].ToString();
            head.Controls.Add(description);
            //keywords
            HtmlMeta Keywords = new HtmlMeta();
            Keywords.Name = "Keywords";
            Keywords.Content = System.Configuration.ConfigurationManager.AppSettings["homepage_keyword"].ToString();
            head.Controls.Add(Keywords);
        }
        /// <summary>
        /// 初始化产品领域列表
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static string InitAreaList()
        {
            List<Model.DBModel.Lilly_TherapeuticAreas> result = BusinessHelper.GetAllAreas();
            StringBuilder innerHTML = new StringBuilder();
            innerHTML.Append("<div class='title'>礼来产品相关治疗领域</div>");
            innerHTML.Append("<p>请选择以下治疗领域:</p>");
            if (result.Count > 0)
            {
                int rowCount = 0;
                if (result.Count % 3 == 0)
                {
                    rowCount = result.Count / 3;
                }
                else
                {
                    rowCount = result.Count / 3 + 1;
                }
                for (int i = 0; i < rowCount; i++)
                {
                    innerHTML.Append("<ul>");
                    for (int j = 0; j < result.Count; j++)
                    {
                        if (j / 3 == i && result[j].Enabled)
                        {
                            innerHTML.Append("<li class='enabled' id='" + result[j].URLPath + "' onclick='area_click(this);'>" + result[j].AreaName + "</li>");
                        }
                        else if (j / 3 == i && !result[j].Enabled)
                        {
                            innerHTML.Append("<li class='disabled' title='即将上线......'>" + result[j].AreaName + "</li>");
                        }
                    }
                    innerHTML.Append("</ul>");
                }
            }
            return innerHTML.ToString();
        }
        /// <summary>
        /// 获取产品搜索框的下拉列表
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public static string GetProductList()
        {
            string sql = "select 'product'+cast(a.ID as varchar) as id,a.name,a.URLPath as PPath,b.URLPath as TPath from Lilly_Medicals a inner join Lilly_TherapeuticAreas b on a.TID=b.ID order by a.name asc";
            DataTable result = BusinessHelper.ExecuteQuery(sql);
            List<ProductOption> list = new List<ProductOption>();
            if (result != null)
            {
                for(int i = 0; i < result.Rows.Count; i++)
                {
                    ProductOption op = new ProductOption();
                    op.id = Convert.ToString(result.Rows[i]["id"]);
                    op.name= Convert.ToString(result.Rows[i]["name"]);
                    op.PPath= Convert.ToString(result.Rows[i]["PPath"]);
                    op.TPath = Convert.ToString(result.Rows[i]["TPath"]);
                    list.Add(op);
                }
            }
            return Newtonsoft.Json.JsonConvert.SerializeObject(list);
        }
        /// <summary>
        /// 判断IP地址访问指定URL是否在有效时间范围内
        /// </summary>
        /// <param name="IPAddress">IP地址</param>
        /// <param name="URL">访问URL地址</param>
        /// <returns>主键ID+'|'+0/1</returns>
        [WebMethod]
        public static string GetClientEffective(string IPAddress,string URL)
        {
            if (IPAddress == "")
            {
                if (System.Web.HttpContext.Current.Session["client_id"] == null)
                {
                    System.Web.HttpContext.Current.Session["client_id"] = Guid.NewGuid().ToString();
                }
                IPAddress = System.Web.HttpContext.Current.Session["client_id"].ToString();
            }
            return BusinessHelper.GetClientEffective(IPAddress, URL);
        }
        /// <summary>
        /// 更新客户访问身份
        /// </summary>
        /// <param name="id"></param>
        /// <param name="flag"></param>
        [WebMethod]
        public static void UptClientLog(string id, string flag)
        {
            string sql = "update Lilly_ClientLog set ishcp=" + flag + " where ID='" + id + "'";
            LillyMedical.Utility.BusinessHelper.ExecuteNonQuery(sql);
        }
    }

    public class ProductOption
    {
        /// <summary>
        /// Product ID
        /// </summary>
        public string id { get; set; }
        /// <summary>
        /// Product Name
        /// </summary>
        public string name { get; set; }
        /// <summary>
        /// Product URLPath
        /// </summary>
        public string PPath { get; set; }
        /// <summary>
        /// 领域 URLPath
        /// </summary>
        public string TPath { get; set; }
    }
}