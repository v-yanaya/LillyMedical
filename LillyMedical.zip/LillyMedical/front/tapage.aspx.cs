﻿using LillyMedical.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace LillyMedical.front
{
    public partial class tapage : System.Web.UI.Page
    {
        public static string areaName, areaID, areaPath;
        protected void Page_Load(object sender, EventArgs e)
        {
            //获取URL中的药品领域ID
            object URLPath = Request.QueryString["URLPath"];
            if (!Page.IsPostBack && URLPath != null)
            {
                Model.DBModel.Lilly_TherapeuticAreas area = BusinessHelper.QueryAreas(" URLPath='" + URLPath.ToString() + "'");
                if (area != null)
                {
                    areaID = area.ID.ToString();
                    areaName = area.AreaName;
                    areaPath = area.URLPath;
                    HtmlHead head = (HtmlHead)Page.Header;
                    HtmlMeta contentType = new HtmlMeta();//显示字符集的设定 设定页面使用的字符集
                    contentType.HttpEquiv = "content-Type";
                    contentType.Content = "text/html; charset=utf-8";
                    head.Controls.Add(contentType);
                    //title
                    HtmlTitle title = new HtmlTitle();
                    title.Text = area.URLTitle;
                    head.Controls.Add(title);
                    //description
                    HtmlMeta description = new HtmlMeta();
                    description.Name = "Description";
                    description.Content = area.Description;
                    head.Controls.Add(description);
                    //keywords
                    HtmlMeta Keywords = new HtmlMeta();
                    Keywords.Name = "Keywords";
                    Keywords.Content = area.KeyWords;
                    head.Controls.Add(Keywords);
                }
            }
        }
        /// <summary>
        /// 根据领域ID获取领域下的产品列表
        /// </summary>
        /// <param name="urlPath"></param>
        /// <returns></returns>
        [WebMethod]
        public static string InitMedicalsList(string areaID)
        {
            List<Model.DBModel.Lilly_Medicals> result = BusinessHelper.AllMedicals(" TID='" + areaID + "'");
            return Newtonsoft.Json.JsonConvert.SerializeObject(result);
        }
    }
}