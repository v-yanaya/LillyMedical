﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LillyMedical.front
{
    public partial class searchresult : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        /// <summary>
        /// 根据产品ID和关键字，进行全文检索
        /// </summary>
        /// <param name="id">产品ID</param>
        /// <param name="keyword">关键字</param>
        /// <returns></returns>
        [WebMethod]
        public static string GetMedicalInfo(int id,string keyword)
        {
            LillyMedical.Model.DBModel.Lilly_Medicals medical= LillyMedical.Utility.BusinessHelper.GetMedicalByID(id);
            if (medical != null)
            {
                LillyMedical.Model.DBModel.Lilly_TherapeuticAreas area = LillyMedical.Utility.BusinessHelper.GetAreaByID(medical.TID);
                if (area != null)
                {
                    LillyMedical.Model.PageModel.searchresult model = new LillyMedical.Model.PageModel.searchresult();
                    model.TID = area.ID;
                    model.AreaName = area.AreaName;
                    model.TaPath = area.URLPath;
                    model.PID = medical.ID;
                    model.PName = medical.Name;
                    model.PrdPath = medical.URLPath;
                    model.Summary = medical.Summary;
                    model.BookLink = LillyMedical.Utility.BusinessHelper.GetBookLinksByMID(medical.ID);
                    model.QAList = LillyMedical.Utility.BusinessHelper.GetQAList(id, keyword);
                    model.Count_S = model.QAList.Count().ToString();
                    model.Count_B = LillyMedical.Utility.NumerFormat.NumToChn(model.Count_S);
                    model.ShowDrugLicense = medical.ShowDrugLicense;
                    return Newtonsoft.Json.JsonConvert.SerializeObject(model);
                }
            }
            return string.Empty;
        }
    }
}