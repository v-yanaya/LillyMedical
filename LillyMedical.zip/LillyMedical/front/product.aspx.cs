﻿using LillyMedical.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace LillyMedical.front
{
    public partial class product : System.Web.UI.Page
    {
        //设置全局变量药品产品名称、领域名称、领域ID
        public static string ProductName, areaName, PID, areaPath;
        public static int TID;
        public static bool ShowDrugLicense;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //获取URL中的药品产品ID
                object id = Request.QueryString["id"];
                if (id != null)
                {
                    PID = id.ToString();
                    LillyMedical.Model.DBModel.Lilly_Medicals prd = BusinessHelper.QueryProduct(" ID='" + PID + "'");
                    ProductName = prd.Name;
                    TID = prd.TID;
                    ShowDrugLicense = prd.ShowDrugLicense;
                    LillyMedical.Model.DBModel.Lilly_TherapeuticAreas area = BusinessHelper.QueryAreas(" ID='" + TID + "'");
                    areaName = area.AreaName;
                    areaPath = area.URLPath;
                    HtmlHead head = (HtmlHead)Page.Header;
                    HtmlMeta contentType = new HtmlMeta();//显示字符集的设定 设定页面使用的字符集
                    contentType.HttpEquiv = "content-Type";
                    contentType.Content = "text/html; charset=utf-8";
                    head.Controls.Add(contentType);
                    //title
                    HtmlTitle title = new HtmlTitle();
                    title.Text = prd.URLTitle;
                    head.Controls.Add(title);
                    //description
                    HtmlMeta description = new HtmlMeta();
                    description.Name = "Description";
                    description.Content = prd.Description;
                    head.Controls.Add(description);
                    //keywords
                    HtmlMeta Keywords = new HtmlMeta();
                    Keywords.Name = "Keywords";
                    Keywords.Content = prd.KeyWords;
                    head.Controls.Add(Keywords);
                }
            }
        }

        [WebMethod]
        public static string InitProductList(int id)
        {
            //根据药品产品ID获取药品详细信息
            LillyMedical.Model.DBModel.Lilly_Medicals medical= BusinessHelper.QueryProduct(" ID='" + id + "'");
            StringBuilder innerHTML = new StringBuilder();
            if (medical != null)
            {
                innerHTML.Append("<div class='title'>" + medical.Name + "</div>");
                //innerHTML.Append("<div class='summary'>" + medical.Summary + "</div>");
                foreach(LillyMedical.Model.DBModel.Lilly_BookLinks bookLink in BusinessHelper.GetBookLinksByMID(id))
                {
                    innerHTML.Append("<div class='booklink'><a href='" + bookLink.BookLink + "' style='color:#0078a3!important;' target='_blank'>" + bookLink.Name+ "</a></div>");
                }
            }
            return innerHTML.ToString();
        }
    }
}