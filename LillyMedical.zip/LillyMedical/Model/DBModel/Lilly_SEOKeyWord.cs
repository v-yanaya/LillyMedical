﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Model.DBModel
{
    /// <summary>
    /// SEO 关键字
    /// </summary>
    public class Lilly_SEOKeyWord
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int ID
        {
            get;set;
        }
        /// <summary>
        /// SEO关键字
        /// </summary>
        public string KeyWord
        {
            get;set;
        }
    }
}