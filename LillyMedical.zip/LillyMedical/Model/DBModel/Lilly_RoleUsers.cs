﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Model.DBModel
{
    /// <summary>
    /// 礼来系统管理用户
    /// </summary>
    public class Lilly_RoleUsers
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int ID
        {
            get;set;
        }
        /// <summary>
        /// 角色名称1. 超级管理员   2. 业务管理员
        /// </summary>
        public string RoleName
        {
            get;set;
        }
        /// <summary>
        /// 用户登陆账号，对应Lilly Domain Account
        /// </summary>
        public string UserAccount
        {
            get;set;
        }
        /// <summary>
        /// 用户姓名
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 状态
        /// </summary>
        public bool Status { get; set; }
        
        public string EditHandler
        {
            get
            {
                return "<a class='a_handler'>编辑</a>";
            }
        }

        public string DeleteHandler
        {
            get
            {
                return "<a class='a_handler'>删除</a>";
            }
        }

        public string DisableHandler { get; set; }
    }
}