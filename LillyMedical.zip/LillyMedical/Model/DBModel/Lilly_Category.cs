﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Model.DBModel
{
    /// <summary>
    /// 问题所属Category
    /// </summary>
    public class Lilly_Category
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int ID
        {
            get;set;
        }
        /// <summary>
        /// Category中文名称
        /// </summary>
        public string Name
        {
            get; set;
        }
        /// <summary>
        /// Category英文名称
        /// </summary>
        public string EnglishName
        {
            get; set;
        }
    }
}