﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Model.DBModel
{
    public class Lilly_UserLogs
    {
        /// <summary>
        /// 主键
        /// </summary>
        public string ID { get; set; }
        /// <summary>
        /// 操作时间
        /// </summary>
        public DateTime Stamp { get; set; }
        /// <summary>
        /// 管理员Global ID
        /// </summary>
        public string UserAccount { get; set; }
        /// <summary>
        /// 操作日志描述
        /// </summary>
        public string LogDetails { get; set; }
    }
}