﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Model.DBModel
{
    /// <summary>
    /// 礼来药品治疗领域
    /// </summary>
    public class Lilly_TherapeuticAreas
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int ID
        {
            get; set;
        }
        /// <summary>
        /// 治疗领域名称
        /// </summary>
        public string AreaName
        {
            get;set;
        }
        /// <summary>
        /// 是否可用
        /// </summary>
        public bool Enabled
        {
            get;set;
        }
        /// <summary>
        /// 用于URL地址中显示的内容，通常可设为药品领域的英文翻译
        /// </summary>
        public string URLPath { get; set; }
        /// <summary>
        /// 用于浏览器访问时的HTML的标题显示，Meta标签
        /// </summary>
        public string URLTitle { get; set; }
        /// <summary>
        /// SEO 关键字，Meta标签
        /// </summary>
        public string KeyWords { get; set; }
        /// <summary>
        /// SEO 描述，Meta标签
        /// </summary>
        public string Description { get; set; }
    }
}