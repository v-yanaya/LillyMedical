﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Model.DBModel
{
    /// <summary>
    /// 药品相关问答信息表
    /// </summary>
    public class Lilly_MedicalQA
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int ID
        {
            get;set;
        }
        /// <summary>
        /// 外键，问题从属的产品，关联表Lilly_Medicals 列ID
        /// </summary>
        public int MID
        {
            get; set;
        }
        /// <summary>
        /// 外键，问题从属的Category，关联表Lilly_Category 列ID
        /// </summary>
        public int CID
        {
            get; set;
        }
        /// <summary>
        /// 全文搜索引擎关键字
        /// </summary>
        public string LocalKeyWord
        {
            get;set;
        }
        /// <summary>
        /// SEO关键字，用于搜索引擎检索
        /// </summary>
        public string SEOKeyWord
        {
            get; set;
        }
        /// <summary>
        /// 上下架状态
        /// </summary>
        public bool Status
        {
            get;set;
        }
        /// <summary>
        /// 问题标题
        /// </summary>
        public string Title
        {
            get; set;
        }
        /// <summary>
        /// 问题内容
        /// </summary>
        public string Answer
        {
            get; set;
        }
        /// <summary>
        /// HTML路径
        /// </summary>
        public string FilePath
        {
            get;set;
        }
        /// <summary>
        /// URL 问题标识ID
        /// </summary>
        public string VeevaID { get; set; }
        /// <summary>
        /// 用于SEO Description Meta标签
        /// </summary>
        public string Description { get; set; }
    }
}