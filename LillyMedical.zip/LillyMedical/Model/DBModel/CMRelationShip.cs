﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Model.DBModel
{
    /// <summary>
    /// 产品和问题所属Category关系
    /// </summary>
    public class CMRelationShip
    {
        /// <summary>
        /// 产品主键ID
        /// </summary>
        public int MID
        {
            get;set;
        }
        /// <summary>
        /// Category主键ID
        /// </summary>
        public int CID
        {
            get;set;
        }
        /// <summary>
        /// Category名称
        /// </summary>
        public string CategoryName
        {
            get;set;
        }
    }
}