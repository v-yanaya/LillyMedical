﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Model.DBModel
{
    /// <summary>
    /// 产品说明书
    /// </summary>
    public class Lilly_BookLinks
    {
        /// <summary>
        /// 主键
        /// </summary>
        public int ID { get; set; }
        /// <summary>
        /// 外键，关联产品表Lilly_Medical的ID
        /// </summary>
        public int MID { get; set; }
        /// <summary>
        /// 产品说明书名称
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// 产品说明书链接地址
        /// </summary>
        public string BookLink { get; set; }
    }
}