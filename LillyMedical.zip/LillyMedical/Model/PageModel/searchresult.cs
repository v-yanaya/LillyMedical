﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Model.PageModel
{
    /// <summary>
    /// 搜索结果页面
    /// </summary>
    public class searchresult
    {
        /// <summary>
        /// 产品领域ID
        /// </summary>
        public int TID { get; set; }
        /// <summary>
        /// 产品所属领域
        /// </summary>
        public string AreaName { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public string TaPath { get; set; }
        /// <summary>
        /// 产品ID
        /// </summary>
        public int PID { get; set; }
        /// <summary>
        /// 产品名称
        /// </summary>
        public string PName { get; set; }
        public string PrdPath { get; set; }
        /// <summary>
        /// 产品描述信息
        /// </summary>
        public string Summary { get; set; }
        /// <summary>
        /// 产品说明书
        /// </summary>
        public List<LillyMedical.Model.DBModel.Lilly_BookLinks> BookLink { get; set; }
        /// <summary>
        /// 数字格式的搜索结果数目
        /// </summary>
        public string Count_S { get; set; }
        /// <summary>
        /// 中文格式的搜索结果数目
        /// </summary>
        public string Count_B { get; set; }
        /// <summary>
        /// 问题列表
        /// </summary>
        public List<SearchResultQA> QAList { get; set; }
        /// <summary>
        /// 是否展示页面底部的药品上市许可持有人信息
        /// </summary>
        public bool ShowDrugLicense { get; set; }
    }
    /// <summary>
    /// SearchResultQA Model类
    /// </summary>
    public class SearchResultQA
    {
        /// <summary>
        /// 问题Title
        /// </summary>
        public string Title { get; set; }
        /// <summary>
        /// 问题URLLink
        /// </summary>
        public string URLLink { get; set; }
    }
}