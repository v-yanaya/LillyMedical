﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace LillyMedical.Model.PageModel
{
    [Serializable]
    [XmlRoot("SamlResponse")]
    public class SamlResponse
    {
        public List<Attribute> AttributeStatement;
    }

    public class Attribute
    {
        [XmlAttribute("Name")]
        public string Name;
        [XmlElement("AttributeValue")]
        public string AttributeValue;
    }
}