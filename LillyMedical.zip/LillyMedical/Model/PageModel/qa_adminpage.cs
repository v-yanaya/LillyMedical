﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Model.PageModel
{
    public class qa_adminpage
    {
        public int ID
        {
            get; set;
        }
        /// <summary>
        /// 问答模型领域名称
        /// </summary>
        public string AreaName;
        /// <summary>
        /// 问答模型中药品名称
        /// </summary>
        public string MedicalName;
        /// <summary>
        /// 问题标题
        /// </summary>
        public string Title
        {
            get; set;
        }
        /// <summary>
        /// URL 问题标识ID
        /// </summary>
        public string VeevaID { get; set; }
        /// <summary>
        /// 问答模型大类名称
        /// </summary>
        public string CategoryName;
        /// <summary>
        /// 上下架状态
        /// </summary>
        public bool Status
        {
            get; set;
        }
        /// <summary>
        /// 操作列，页面绑定时使用，其余情况可忽略该字段
        /// </summary>
        public string Handler { get; set; }
        /// <summary>
        /// 操作列，页面绑定时使用，其余情况可忽略该字段
        /// </summary>
        public string Edit { get; set; }
    }
}