﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Serialization;
using LillyMedical.Model.PageModel;
using System.IO;
using LillyMedical.Utility;

namespace LillyMedical.master
{
    public partial class no_sso : System.Web.UI.MasterPage
    {
        //string sso_login = System.Configuration.ConfigurationManager.AppSettings["sso_login"].ToString();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (LillyMedical.Utility.UserHelper.CurrentLoginUserInfo != null)
            {
                lbl_currentuser.Text = LillyMedical.Utility.UserHelper.CurrentLoginUserInfo.GlobalID;
                if (LillyMedical.Utility.UserHelper.CurrentLoginUserInfo.displayname != "")
                {
                    lbl_currentuser.Text = LillyMedical.Utility.UserHelper.CurrentLoginUserInfo.displayname;
                }
            }
            else
            {
                Response.Redirect("../files/time_out.html");
                return;
            }
        }
    }
}