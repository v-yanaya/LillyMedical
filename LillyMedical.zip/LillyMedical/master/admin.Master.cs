﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Serialization;
using LillyMedical.Model.PageModel;
using System.IO;
using LillyMedical.Utility;

namespace LillyMedical.master
{
    public partial class admin : System.Web.UI.MasterPage
    {
        public static bool IsSystemAdmin = false;
        protected void Page_Load(object sender, EventArgs e)
        {
            string rawSamlData = Request["SAMLResponse"];
            string sso_login = System.Configuration.ConfigurationManager.AppSettings["sso_login"].ToString();
            if (rawSamlData == null)
            {
                Response.Redirect(sso_login);
                return;
            }
            byte[] samlData = Convert.FromBase64String(rawSamlData);
            string samlAssertion = Encoding.UTF8.GetString(samlData);
            LogFileHandler.RecordSAMLMeta(samlAssertion);
            if (!ValidateSAMLResponse(samlAssertion))
            {
                Response.Redirect("../files/no_out.html");
                return;
            }
            int start = samlAssertion.IndexOf("<AttributeStatement>");
            int end = samlAssertion.IndexOf("</AttributeStatement>");
            string xml = samlAssertion.Substring(start, end - start + 21);
            xml = "<?xml version=\"1.0\" encoding=\"utf - 8\"?><SamlResponse xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\">"
                + xml + "</SamlResponse>";

            XmlSerializer serializer = new XmlSerializer(typeof(SamlResponse));
            SamlResponse saml = null;
            using (MemoryStream ms = new MemoryStream(Encoding.UTF8.GetBytes(xml)))
            {
                using (StreamReader sr = new StreamReader(ms, Encoding.UTF8))
                {
                    saml = (SamlResponse)serializer.Deserialize(sr);
                }
            }
            if (saml != null)
            {
                SSOLoginUserInfo userInfo = new SSOLoginUserInfo();
                foreach (LillyMedical.Model.PageModel.Attribute attr in saml.AttributeStatement)
                {
                    if (attr.Name.Contains("displayname"))
                    {
                        lbl_currentuser.Text = attr.AttributeValue;
                        userInfo.displayname = attr.AttributeValue;
                    }
                    if (attr.Name.Contains("givenname"))
                    {
                        userInfo.givenname = attr.AttributeValue;
                    }
                    if (attr.Name.Contains("surname"))
                    {
                        userInfo.surname = attr.AttributeValue;
                    }
                    if (attr.Name.Contains("emailaddress"))
                    {
                        userInfo.emailaddress = attr.AttributeValue;
                    }
                    if (attr.Name.Contains("claims/name"))
                    {
                        userInfo.claims_name = attr.AttributeValue;
                    }
                    if(attr.Name.Contains("Global ID"))
                    {
                        userInfo.GlobalID = attr.AttributeValue;
                        if (lbl_currentuser.Text == string.Empty)
                        {
                            lbl_currentuser.Text = attr.AttributeValue;
                        }
                    }
                }
                ValidateSSOUserInfo(userInfo);
            }
        }
        /// <summary>
        /// 验证当前登陆用户是否拥有权限
        /// </summary>
        /// <param name="ssouser"></param>
        public void ValidateSSOUserInfo(SSOLoginUserInfo sso)
        {
            bool IfHasAccess = false;
            foreach (LillyMedical.Model.DBModel.Lilly_RoleUsers user in LillyMedical.Utility.BusinessHelper.GetAllUsers())
            {
                if ((user.UserAccount == sso.displayname || user.UserAccount == sso.GlobalID) && user.RoleName.Trim() != "" && user.Status)
                {
                    IfHasAccess = true;
                    sso.role_name = user.RoleName;
                    break;
                }
            }
            if (IfHasAccess)
            {
                LillyMedical.Utility.UserHelper.CurrentLoginUserInfo = sso;
                LillyMedical.Model.DBModel.Lilly_UserLogs log = new Model.DBModel.Lilly_UserLogs();
                log.UserAccount = sso.GlobalID;
                if (string.IsNullOrEmpty(log.UserAccount))
                {
                    log.UserAccount = sso.displayname;
                }
                IsSystemAdmin = LillyMedical.Utility.UserHelper.CurrentLoginUserInfo.role_name.Contains("系统管理员");
                log.LogDetails = "SSO 单点登录成功";
                LillyMedical.Utility.LogFileHandler.RecordUserLog(log);
            }
            else
            {
                Response.Write("<script type='text/javascript'>window.location.href='../files/no-access.html';</script>");
            }            
        }

        protected void btn_user_manage_Click(object sender, EventArgs e)
        {
            Response.Redirect("usermanage.aspx");
        }

        public bool ValidateSAMLResponse(string samlResponse)
        {
            string sso_login = System.Configuration.ConfigurationManager.AppSettings["sso_login"].ToString();
            if (!samlResponse.Contains("samlp:Response"))
            {
                if (LillyMedical.Utility.UserHelper.CurrentLoginUserInfo == null)
                {
                    return false;
                }
            }
            string path = LillyMedical.Utility.LogFileHandler.GetWebRootPath() + @"\\Certificates\\" + "LillyMedical.cer";
            string cer = File.ReadAllText(path).Replace("\r","").Replace("\n","");
            int start = samlResponse.IndexOf("<X509Certificate>");
            int end = samlResponse.IndexOf("</X509Certificate>");
            string X509 = samlResponse.Substring(start + 17, end - start - 17);
            string xml = X509.Substring(X509.Length-50, 50);
            if (cer.Contains(xml))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}