﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace LillyMedical.Utility
{
    /// <summary>
    /// 业务操作类
    /// </summary>
    public class BusinessHelper
    {
        /// <summary>
        /// 查询所有的治疗领域信息
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_TherapeuticAreas> GetAllAreas()
        {
            return DBHelper.QueryAreas();
        }
        /// <summary>
        /// 根据ID获取治疗领域信息
        /// </summary>
        /// <returns></returns>
        public static LillyMedical.Model.DBModel.Lilly_TherapeuticAreas GetAreaByID(int id)
        {
            foreach(LillyMedical.Model.DBModel.Lilly_TherapeuticAreas area in DBHelper.QueryAreas())
            {
                if (area.ID == id)
                {
                    return area;
                }
            }
            return null;
        }
        /// <summary>
        /// 获取所有产品
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_Medicals> GetAllMedecials()
        {
            return DBHelper.GetAllMedicals();
        }
        /// <summary>
        /// 获取所有Category
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_Category> GetAllCategory()
        {
            return DBHelper.GetAllCategory();
        }
        /// <summary>
        /// 获取所有产品的问答信息，包括已上架和已下架
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_MedicalQA> GetAllMedicalQA()
        {
            return DBHelper.GetAllMedicalQA();
        }
        /// <summary>
        /// 获取产品和问题所属Category关系表
        /// </summary>
        /// <returns></returns>
        public static List<Model.DBModel.CMRelationShip> GetCMRelationShip()
        {
            return DBHelper.GetCMRelationShip();
        }
        /// <summary>
        /// 判断当前IP地址访问是否在有效期内，如果已经失效，则添加访问记录
        /// </summary>
        /// <param name="IPAddress">客户端IP Address</param>
        /// <param name="URL">客户端访问路径</param>
        /// <returns>主键ID+'|'+0/1</returns>
        public static string GetClientEffective(string IPAddress,string URL)
        {
            return DBHelper.GetClientEffective(IPAddress, URL);
        }
        /// <summary>
        /// 查询所有的治疗领域信息
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_Medicals> AllMedicals(string Sqlwhere)
        {
            return DBHelper.QueryMedicals(Sqlwhere);
        }

        /// <summary>
        /// 查询药品详情
        /// </summary>
        /// <returns></returns>
        public static LillyMedical.Model.DBModel.Lilly_Medicals QueryProduct(string Sqlwhere)
        {
            return DBHelper.QueryProduct(Sqlwhere);
        }
        /// <summary>
        /// 新增产品QA数据
        /// </summary>
        /// <param name="qa"></param>
        /// <returns>产品QA信息主键</returns>
        public static int AddMedicalQA(LillyMedical.Model.DBModel.Lilly_MedicalQA qa)
        {
            return DBHelper.AddMedicalQA(qa);
        }
        /// <summary>
        /// 更新产品QA数据
        /// </summary>
        /// <param name="qa"></param>
        /// <returns>产品QA信息主键</returns>
        public static int UpdateMedicalQA(LillyMedical.Model.DBModel.Lilly_MedicalQA qa)
        {
            return DBHelper.UpdateMedicalQA(qa);
        }
        /// <summary>
        /// 处理QA HTML文件，获取Body标签
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static string BodyHandler(string html)
        {
            string result = string.Empty;
            if (html != "")
            {
                result = html.Substring(html.IndexOf("<body"), html.LastIndexOf("</body>") - html.IndexOf("<body") + 7);
                result = result.Replace("body", "div");
            }
            return result;
        }
        /// <summary>
        /// 存储问答数据
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static void AnswerHandler(string id,string content)
        {
            LillyMedical.Utility.DBHelper.AnswerHandler(id, content);
        }
        /// <summary>
        /// 处理QA HTML文件，获取Style标签
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static string StyleHandler(string html)
        {
            string result = "";
            if (html != "")
            {
                result = html.Substring(html.IndexOf("<style"), html.LastIndexOf("</style>") - html.IndexOf("<style") + 8);
                result = result.Replace("body", "");
            }
            return result;
        }
        /// <summary>
        /// 根据ID获取QA信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static LillyMedical.Model.DBModel.Lilly_MedicalQA GetMedicalQAByID(string id)
        {
            return DBHelper.GetMedicalQAByID(id);
        }
        /// <summary>
        /// 根据ID获取Medical信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static LillyMedical.Model.DBModel.Lilly_Medicals GetMedicalByID(int id)
        {
            foreach(LillyMedical.Model.DBModel.Lilly_Medicals medical in DBHelper.GetAllMedicals())
            {
                if (medical.ID == id)
                {
                    return medical;
                }
            }
            return null;
        }

        /// <summary>
        /// 查询领域详情
        /// </summary>
        /// <returns></returns>
        public static LillyMedical.Model.DBModel.Lilly_TherapeuticAreas QueryAreas(string Sqlwhere)
        {
            return DBHelper.QueryAreas(Sqlwhere);
        }

        /// <summary>
        /// 联合查询QA问答列表
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.PageModel.qa_adminpage> Lilly_MedicalQAList(int status, int areas, int product,
            int category, string veevaid, string qatitle)
        {
            return DBHelper.Lilly_MedicalQAList(status, areas, product, category, veevaid, qatitle);
        }
        /// <summary>
        /// 获取所有管理员信息
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_RoleUsers> GetAllUsers()
        {
            return DBHelper.GetAllUsers();
        }
        /// <summary>
        /// 修改QA问答状态
        /// </summary>
        /// <returns></returns>
        public static bool UpdateMedicalQAStatus(int ID, int status)
        {
            if (UserHelper.CurrentLoginUserInfo == null)
            {
                throw new Exception("Session Time Out");
            }
            bool result = DBHelper.UpdateMedicalQAStatus(ID, status);
            LillyMedical.Model.DBModel.Lilly_MedicalQA qa= GetMedicalQAByID(ID.ToString());
            if (qa != null)
            {
                LillyMedical.Model.DBModel.Lilly_UserLogs log = new Model.DBModel.Lilly_UserLogs();
                log.UserAccount = UserHelper.CurrentLoginUserInfo.GlobalID;
                if (string.IsNullOrEmpty(log.UserAccount))
                {
                    log.UserAccount= UserHelper.CurrentLoginUserInfo.displayname;
                }
                if (status == 1)
                {
                    log.LogDetails = "将问题 "+qa.Title+" 上架";
                }
                else
                {
                    log.LogDetails = "将问题 " + qa.Title + " 下架";
                }
                LillyMedical.Utility.LogFileHandler.RecordUserLog(log);
            }
            return result;
        }
        /// <summary>
        /// 搜索问题列表
        /// </summary>
        /// <param name="pid"></param>
        /// <param name="keyword"></param>
        /// <returns></returns>
        public static List<LillyMedical.Model.PageModel.SearchResultQA> GetQAList(int pid, string keyword)
        {
            DataTable dt = DBHelper.GetQAList(pid, keyword);
            List<LillyMedical.Model.PageModel.SearchResultQA> result = new List<Model.PageModel.SearchResultQA>();

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                if (dt.Rows[i]["Status"] == DBNull.Value || !Convert.ToBoolean(dt.Rows[i]["Status"]))
                {
                    continue;
                }
                LillyMedical.Model.PageModel.SearchResultQA qa = new Model.PageModel.SearchResultQA();
                qa.Title = LillyMedical.Utility.BusinessHelper.FormatTradeMark(Convert.ToString(dt.Rows[i]["Title"]));
                string url = HttpContext.Current.Request.Url.ToString();
                qa.URLLink = url.Substring(0, url.IndexOf("/front")) + "/zh-cn/answer/" + Convert.ToString(dt.Rows[i]["VeevaID"]);
                result.Add(qa);
            }

            return result;
        }
        /// <summary>
        /// 执行SQL更新语句
        /// </summary>
        /// <param name="sql">要执行的完整SQL语句</param>
        public static void ExecuteNonQuery(string sql)
        {
            DBHelper.ExecuteNonQuery(sql);
        }
        /// <summary>
        /// 执行SQL查询语句
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static DataTable ExecuteQuery(string sql)
        {
            return DBHelper.ExecuteQuery(sql);
        }
        /// <summary>
        /// 根据产品ID获取产品说明书
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_BookLinks> GetBookLinksByMID(int id)
        {
            return DBHelper.GetBookLinksByMID(id);
        }
        /// <summary>
        /// VeevaID唯一性验证
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="VeevaID"></param>
        /// <returns></returns>
        public static bool ValVeevaID(string Id, string VeevaID)
        {
            return DBHelper.ValVeevaID(Id, VeevaID);
        }
        /// <summary>
        /// 根据VeevaID获取QA信息
        /// </summary>
        /// <param name="VeevaID"></param>
        /// <returns></returns>
        public static LillyMedical.Model.DBModel.Lilly_MedicalQA GetQAByVeevaID(string VeevaID)
        {
            return DBHelper.GetQAByVeevaID(VeevaID);
        }
        /// <summary>
        /// 将R图标上标
        /// </summary>
        /// <param name="val"></param>
        /// <returns></returns>
        public static string FormatTradeMark(string val)
        {
            return val.Replace("®", "<sup>®</sup>");
        }
    }
}