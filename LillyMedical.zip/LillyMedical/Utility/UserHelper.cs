﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LillyMedical.Utility
{
    public class UserHelper
    {
        public const string session_key = "sso_login_user";        
        public static SSOLoginUserInfo CurrentLoginUserInfo
        {
            get
            {
                if (System.Web.HttpContext.Current.Session["session_key"] == null)
                {
                    return null;
                }
                return System.Web.HttpContext.Current.Session["session_key"] as SSOLoginUserInfo;
            }
            set
            {
                System.Web.HttpContext.Current.Session["session_key"] = value;
            }
        }
    }

    public class SSOLoginUserInfo
    {
        /// <summary>
        /// 全名
        /// </summary>
        public string displayname { get; set; }
        /// <summary>
        /// 名字
        /// </summary>
        public string givenname { get; set; }
        /// <summary>
        /// 姓
        /// </summary>
        public string surname { get; set; }
        /// <summary>
        /// 邮件地址
        /// </summary>
        public string emailaddress { get; set; }
        public string claims_name { get; set; }
        public string GlobalID { get; set; }

        public string role_name { get; set; }
    }
}