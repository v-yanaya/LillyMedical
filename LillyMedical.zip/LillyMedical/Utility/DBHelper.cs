﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace LillyMedical.Utility
{
    /// <summary>
    /// 数据库操作类
    /// </summary>
    public class DBHelper
    {
        public static string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["lillymedical"].ToString();
        /// <summary>
        /// 查询药品治疗领域
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_TherapeuticAreas> QueryAreas()
        {
            List<LillyMedical.Model.DBModel.Lilly_TherapeuticAreas> result = new List<LillyMedical.Model.DBModel.Lilly_TherapeuticAreas>();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from dbo.Lilly_TherapeuticAreas order by id asc";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_TherapeuticAreas area = new Model.DBModel.Lilly_TherapeuticAreas();
                    area.ID = Convert.ToInt32(sdreader["ID"]);
                    area.AreaName = sdreader["AreaName"].ToString();
                    area.Enabled = Convert.ToBoolean(sdreader["Enabled"]);
                    area.URLPath = Convert.ToString(sdreader["URLPath"]);
                    area.URLTitle = Convert.ToString(sdreader["URLTitle"]);
                    area.KeyWords = Convert.ToString(sdreader["KeyWords"]);
                    area.Description = Convert.ToString(sdreader["Description"]);
                    result.Add(area);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }
        /// <summary>
        /// 获取所有产品
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_Medicals> GetAllMedicals()
        {
            List<LillyMedical.Model.DBModel.Lilly_Medicals> result = new List<LillyMedical.Model.DBModel.Lilly_Medicals>();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from Lilly_Medicals";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_Medicals medical = new Model.DBModel.Lilly_Medicals();
                    medical.ID = Convert.ToInt32(sdreader["ID"]);
                    medical.TID = Convert.ToInt32(sdreader["TID"]);
                    medical.Name = Convert.ToString(sdreader["Name"]);
                    medical.Summary = Convert.ToString(sdreader["Summary"]);
                    medical.URLPath = Convert.ToString(sdreader["URLPath"]);
                    medical.URLTitle = Convert.ToString(sdreader["URLTitle"]);
                    medical.Description = Convert.ToString(sdreader["Description"]);
                    medical.ShowDrugLicense = sdreader["ShowDrugLicense"] == DBNull.Value ? false : Convert.ToBoolean(sdreader["ShowDrugLicense"]);
                    result.Add(medical);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }
        /// <summary>
        /// 获取所有Category
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_Category> GetAllCategory()
        {
            List<LillyMedical.Model.DBModel.Lilly_Category> result = new List<LillyMedical.Model.DBModel.Lilly_Category>();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from Lilly_Category";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_Category category = new Model.DBModel.Lilly_Category();
                    category.ID = Convert.ToInt32(sdreader["ID"]);
                    category.Name = Convert.ToString(sdreader["Name"]);
                    category.EnglishName = Convert.ToString(sdreader["EnglishName"]);
                    result.Add(category);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }
        /// <summary>
        /// 获取所有产品的问答信息，包括已上架和已下架
        /// </summary>
        /// <returns></returns>
        public static List<Model.DBModel.Lilly_MedicalQA> GetAllMedicalQA()
        {
            List<LillyMedical.Model.DBModel.Lilly_MedicalQA> result = new List<LillyMedical.Model.DBModel.Lilly_MedicalQA>();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from Lilly_MedicalQA";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_MedicalQA qa = new Model.DBModel.Lilly_MedicalQA();
                    qa.ID = Convert.ToInt32(sdreader["ID"]);
                    qa.MID = Convert.ToInt32(sdreader["MID"]);
                    qa.CID = Convert.ToInt32(sdreader["CID"]);
                    qa.LocalKeyWord = Convert.ToString(sdreader["LocalKeyWord"]);
                    qa.SEOKeyWord = Convert.ToString(sdreader["SEOKeyWord"]);
                    qa.Title = Convert.ToString(sdreader["Title"]);
                    qa.Answer = Convert.ToString(sdreader["Answer"]);
                    qa.Status = Convert.ToBoolean(sdreader["Status"]);
                    qa.VeevaID = Convert.ToString(sdreader["VeevaID"]);
                    result.Add(qa);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }
        /// <summary>
        /// 获取产品和问题所属Category关系表
        /// </summary>
        /// <returns></returns>
        public static List<Model.DBModel.CMRelationShip> GetCMRelationShip()
        {
            List<LillyMedical.Model.DBModel.CMRelationShip> result = new List<LillyMedical.Model.DBModel.CMRelationShip>();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select distinct b.ID as CID,a.ID as MID,b.Name as CategoryName from Lilly_MedicalQA a inner join Lilly_Category b on a.CID=b.ID";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.CMRelationShip rel = new Model.DBModel.CMRelationShip();
                    rel.CID = Convert.ToInt32(sdreader["CID"]);
                    rel.MID = Convert.ToInt32(sdreader["MID"]);
                    rel.CategoryName = Convert.ToString(sdreader["CategoryName"]);
                    result.Add(rel);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }
        /// <summary>
        /// 判断当前IP地址访问是否在有效期内，如果已经失效，则添加访问记录
        /// </summary>
        /// <param name="IPAddress">客户端IP Address</param>
        /// <param name="URL">客户端访问路径</param>
        /// <returns>主键ID+'|'+0/1</returns>
        public static string GetClientEffective(string IPAddress,string URL)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            string result = "";
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sp = "sp_getclienteffective";
                comm = new SqlCommand(sp);
                comm.CommandType = CommandType.StoredProcedure;
                comm.Connection = conn;
                SqlParameter ip = new SqlParameter("@IPAddress", IPAddress);
                comm.Parameters.Add(ip);
                SqlParameter url = new SqlParameter("@URL", URL);
                comm.Parameters.Add(url);
                result = Convert.ToString(comm.ExecuteScalar());
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                conn.Close();
            }
            return result;
        }
        /// <summary>
        /// 查询领域下所属药品
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_Medicals> QueryMedicals(string Sqlwhere)
        {
            List<LillyMedical.Model.DBModel.Lilly_Medicals> result = new List<LillyMedical.Model.DBModel.Lilly_Medicals>();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from dbo.Lilly_Medicals where " + Sqlwhere + " order by id asc";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_Medicals medicals = new Model.DBModel.Lilly_Medicals();
                    medicals.ID = Convert.ToInt32(sdreader["ID"]);
                    medicals.Name = sdreader["Name"].ToString();
                    medicals.Summary = sdreader["Summary"].ToString();
                    medicals.URLPath = Convert.ToString(sdreader["URLPath"]);
                    medicals.URLTitle = Convert.ToString(sdreader["URLTitle"]);
                    medicals.KeyWords = Convert.ToString(sdreader["KeyWords"]);
                    medicals.Description = Convert.ToString(sdreader["Description"]);
                    result.Add(medicals);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }
        /// <summary>
        /// 查询药品详情
        /// </summary>
        /// <returns></returns>
        public static LillyMedical.Model.DBModel.Lilly_Medicals QueryProduct(string Sqlwhere)
        {
            LillyMedical.Model.DBModel.Lilly_Medicals result = new LillyMedical.Model.DBModel.Lilly_Medicals();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from dbo.Lilly_Medicals where " + Sqlwhere + " order by id asc";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_Medicals medicals = new Model.DBModel.Lilly_Medicals();
                    result.ID = Convert.ToInt32(sdreader["ID"]);
                    result.TID = Convert.ToInt32(sdreader["TID"]);
                    result.Name = sdreader["Name"].ToString();
                    result.Summary = sdreader["Summary"].ToString();
                    result.URLTitle = Convert.ToString(sdreader["URLTitle"]);
                    result.URLPath = Convert.ToString(sdreader["URLPath"]);
                    result.KeyWords = Convert.ToString(sdreader["KeyWords"]);
                    result.Description = Convert.ToString(sdreader["Description"]);
                    result.ShowDrugLicense = sdreader["ShowDrugLicense"] == DBNull.Value ? false : Convert.ToBoolean(sdreader["ShowDrugLicense"]);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }
        /// <summary>
        /// 新增产品QA数据
        /// </summary>
        /// <param name="qa"></param>
        /// <returns>产品QA信息主键</returns>
        public static int AddMedicalQA(LillyMedical.Model.DBModel.Lilly_MedicalQA qa)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "insert into Lilly_MedicalQA select @MID,@CID,@LocalKeyWord,@SEOKeyWord,@Title,@Answer,@FilePath,1,@VeevaID,@Description  select max(id) from Lilly_MedicalQA";
                comm = new SqlCommand(sql);
                SqlParameter sp1 = new SqlParameter("@MID", qa.MID.ToString());
                comm.Parameters.Add(sp1);
                SqlParameter sp2 = new SqlParameter("@CID", qa.CID.ToString());
                comm.Parameters.Add(sp2);
                SqlParameter sp3 = new SqlParameter("@LocalKeyWord", qa.LocalKeyWord.ToString());
                comm.Parameters.Add(sp3);
                SqlParameter sp4 = new SqlParameter("@SEOKeyWord", qa.SEOKeyWord.ToString());
                comm.Parameters.Add(sp4);
                SqlParameter sp5 = new SqlParameter("@Title", qa.Title.ToString());
                comm.Parameters.Add(sp5);
                SqlParameter sp6 = new SqlParameter("@Answer", "");
                comm.Parameters.Add(sp6);
                SqlParameter sp7 = new SqlParameter("@FilePath", qa.FilePath);
                comm.Parameters.Add(sp7);
                SqlParameter sp8 = new SqlParameter("@VeevaID", qa.VeevaID);
                comm.Parameters.Add(sp8);
                SqlParameter sp9 = new SqlParameter("@Description", qa.Description);
                comm.Parameters.Add(sp9);
                comm.Connection = conn;
                comm.CommandType = CommandType.Text;
                object id = comm.ExecuteScalar();
                if (id != null && id != DBNull.Value)
                {
                    return Convert.ToInt32(id);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                conn.Close();
            }
            return 0;
        }
        /// <summary>
        /// 更新产品QA数据
        /// </summary>
        /// <param name="qa"></param>
        /// <returns>产品QA信息主键</returns>
        public static int UpdateMedicalQA(LillyMedical.Model.DBModel.Lilly_MedicalQA qa)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "update Lilly_MedicalQA set MID=@MID,CID=@CID,LocalKeyWord=@LocalKeyWord,SEOKeyWord=@SEOKeyWord,Title=@Title,Answer=@Answer,FilePath=@FilePath,VeevaID=@VeevaID,Description=@Description where ID=@ID";
                comm = new SqlCommand(sql);
                SqlParameter sp1 = new SqlParameter("@MID", qa.MID.ToString());
                comm.Parameters.Add(sp1);
                SqlParameter sp2 = new SqlParameter("@CID", qa.CID.ToString());
                comm.Parameters.Add(sp2);
                SqlParameter sp3 = new SqlParameter("@LocalKeyWord", qa.LocalKeyWord.ToString());
                comm.Parameters.Add(sp3);
                SqlParameter sp4 = new SqlParameter("@SEOKeyWord", qa.SEOKeyWord.ToString());
                comm.Parameters.Add(sp4);
                SqlParameter sp5 = new SqlParameter("@Title", qa.Title.ToString());
                comm.Parameters.Add(sp5);
                SqlParameter sp6 = new SqlParameter("@Answer", qa.Answer.Replace("'", "''"));
                comm.Parameters.Add(sp6);
                SqlParameter sp7 = new SqlParameter("@FilePath", qa.FilePath);
                comm.Parameters.Add(sp7);
                SqlParameter sp8 = new SqlParameter("@VeevaID", qa.VeevaID);
                comm.Parameters.Add(sp8);
                SqlParameter sp9 = new SqlParameter("@Description", qa.Description);
                comm.Parameters.Add(sp9);
                SqlParameter sp10 = new SqlParameter("@ID", qa.ID.ToString());
                comm.Parameters.Add(sp10);
                comm.Connection = conn;
                comm.CommandType = CommandType.Text;
                object id = comm.ExecuteScalar();
                if (id != null && id != DBNull.Value)
                {
                    return Convert.ToInt32(id);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                conn.Close();
            }
            return 0;
        }
        /// <summary>
        /// 获取所有SEO关键字
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_SEOKeyWord> GetAllSEOKeyWords()
        {
            List<LillyMedical.Model.DBModel.Lilly_SEOKeyWord> result = new List<LillyMedical.Model.DBModel.Lilly_SEOKeyWord>();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from Lilly_SEOKeyWord";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_SEOKeyWord seo = new Model.DBModel.Lilly_SEOKeyWord();
                    seo.ID = Convert.ToInt32(sdreader["ID"]);
                    seo.KeyWord = Convert.ToString(sdreader["KeyWord"]);
                    result.Add(seo);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }
        /// <summary>
        /// 根据ID获取QA信息
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static LillyMedical.Model.DBModel.Lilly_MedicalQA GetMedicalQAByID(string id)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from Lilly_MedicalQA where ID=@id";
                comm = new SqlCommand(sql);
                SqlParameter para = new SqlParameter("@id", SqlDbType.VarChar);
                para.Value = id;
                comm.Parameters.Add(para);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                LillyMedical.Model.DBModel.Lilly_MedicalQA qa = new Model.DBModel.Lilly_MedicalQA();
                while (sdreader.Read())
                {
                    qa.ID = Convert.ToInt32(sdreader["ID"]);
                    qa.MID = Convert.ToInt32(sdreader["MID"]);
                    qa.CID = Convert.ToInt32(sdreader["CID"]);
                    qa.LocalKeyWord= Convert.ToString(sdreader["LocalKeyWord"]);
                    qa.SEOKeyWord = Convert.ToString(sdreader["SEOKeyWord"]);
                    qa.Title = Convert.ToString(sdreader["Title"]);
                    qa.Answer = Convert.ToString(sdreader["Answer"]);
                    qa.FilePath = Convert.ToString(sdreader["FilePath"]);
                    qa.Status = Convert.ToBoolean(sdreader["Status"]);
                    qa.VeevaID = Convert.ToString(sdreader["VeevaID"]);
                    qa.Description = Convert.ToString(sdreader["Description"]);
                }
                return qa;
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return null;
        }

        /// <summary>
        /// 查询领域详情
        /// </summary>
        /// <returns></returns>
        public static LillyMedical.Model.DBModel.Lilly_TherapeuticAreas QueryAreas(string Sqlwhere)
        {
            LillyMedical.Model.DBModel.Lilly_TherapeuticAreas result = new LillyMedical.Model.DBModel.Lilly_TherapeuticAreas();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from dbo.Lilly_TherapeuticAreas where " + Sqlwhere + " order by id asc";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    result.ID = Convert.ToInt32(sdreader["ID"]);
                    result.AreaName = sdreader["AreaName"].ToString();
                    result.Enabled = Convert.ToBoolean(sdreader["Enabled"]);
                    result.URLPath = Convert.ToString(sdreader["URLPath"]);
                    result.URLTitle = Convert.ToString(sdreader["URLTitle"]);
                    result.KeyWords = Convert.ToString(sdreader["KeyWords"]);
                    result.Description = Convert.ToString(sdreader["Description"]);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }

        /// <summary>
        /// 查询QA问答列表
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_MedicalQA> ListLilly_MedicalQA(string Sqlwhere)
        {
            List<LillyMedical.Model.DBModel.Lilly_MedicalQA> result = new List<LillyMedical.Model.DBModel.Lilly_MedicalQA>();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from dbo.Lilly_MedicalQA where " + Sqlwhere + " order by MID asc";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_MedicalQA medicalQA = new Model.DBModel.Lilly_MedicalQA();
                    medicalQA.ID = Convert.ToInt32(sdreader["ID"]);
                    medicalQA.MID = Convert.ToInt32(sdreader["MID"]);
                    medicalQA.CID = Convert.ToInt32(sdreader["CID"]);
                    medicalQA.LocalKeyWord = sdreader["LocalKeyWord"].ToString();
                    medicalQA.SEOKeyWord = sdreader["SEOKeyWord"].ToString();
                    medicalQA.Title = sdreader["SummTitleary"].ToString();
                    medicalQA.Answer = sdreader["Answer"].ToString();
                    medicalQA.FilePath = sdreader["FilePath"].ToString();
                    medicalQA.Status = Convert.ToBoolean(sdreader["BookLink"]);
                    result.Add(medicalQA);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }

        /// <summary>
        /// 查询QA问答列表
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.PageModel.qa_adminpage> Lilly_MedicalQAList(int status, int areas, int product, 
            int category, string veevaid, string qatitle)
        {
            List<LillyMedical.Model.PageModel.qa_adminpage> result = new List<LillyMedical.Model.PageModel.qa_adminpage>();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                comm = new SqlCommand();
                comm.CommandType = CommandType.StoredProcedure;
                comm.CommandText = "sp_getqalist";
                comm.Connection = conn;
                SqlParameter sp1 = new SqlParameter("@status", SqlDbType.Int);
                sp1.Value = status;
                comm.Parameters.Add(sp1);
                SqlParameter sp2 = new SqlParameter("@areas",SqlDbType.Int);
                sp2.Value = areas;
                comm.Parameters.Add(sp2);
                SqlParameter sp3 = new SqlParameter("@product", SqlDbType.Int);
                sp3.Value = product;
                comm.Parameters.Add(sp3);
                SqlParameter sp4 = new SqlParameter("@category", SqlDbType.Int);
                sp4.Value = category;
                comm.Parameters.Add(sp4);
                SqlParameter sp5 = new SqlParameter("@veevaid", SqlDbType.VarChar,100);
                sp5.Value = veevaid;
                comm.Parameters.Add(sp5);
                SqlParameter sp6 = new SqlParameter("@qatitle", SqlDbType.VarChar,100);
                sp6.Value = qatitle;
                comm.Parameters.Add(sp6);

                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.PageModel.qa_adminpage qa = new Model.PageModel.qa_adminpage();
                    qa.ID = Convert.ToInt32(sdreader["ID"]);
                    qa.Title = BusinessHelper.FormatTradeMark(sdreader["Title"].ToString());
                    qa.VeevaID = Convert.ToString(sdreader["VeevaID"]);
                    qa.Status = Convert.ToBoolean(sdreader["Status"]);
                    qa.AreaName = sdreader["AreaName"].ToString();
                    qa.MedicalName = sdreader["MedicalName"].ToString();
                    qa.CategoryName = sdreader["CategoryName"].ToString();
                    qa.Edit = "<a class='a_handler'>编辑</a>";
                    if (qa.Status)
                    {
                        qa.Handler = "<a class='a_handler'>下架</a>";
                    }
                    else
                    {
                        qa.Handler = "<a class='a_handler'>上架</a>";
                    }
                    result.Add(qa);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }

        /// <summary>
        /// 获取所有管理员信息
        /// </summary>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_RoleUsers> GetAllUsers()
        {
            List<LillyMedical.Model.DBModel.Lilly_RoleUsers> result = new List<LillyMedical.Model.DBModel.Lilly_RoleUsers>();
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from Lilly_RoleUsers order by UserAccount asc";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_RoleUsers user = new Model.DBModel.Lilly_RoleUsers();
                    user.ID = Convert.ToInt32(sdreader["ID"]);
                    user.RoleName = Convert.ToString(sdreader["RoleName"]);
                    user.UserAccount = Convert.ToString(sdreader["UserAccount"]);
                    user.UserName = Convert.ToString(sdreader["UserName"]);
                    user.Status = Convert.ToBoolean(sdreader["Status"]);
                    if (user.Status)
                    {
                        user.DisableHandler = "<a class='a_handler'>禁用</a>";
                    }
                    else
                    {
                        user.DisableHandler = "<a class='a_handler'>启用</a>";
                    }
                    result.Add(user);
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return result;
        }

        /// <summary>
        /// 修改QA问答状态
        /// </summary>
        /// <returns></returns>
        public static bool UpdateMedicalQAStatus(int ID, int status)
        {
            SqlConnection sqlCnt = new SqlConnection(connectionString);
            bool rowcount = true;
            try
            {
                string updateQuery = "update Lilly_MedicalQA set Status='" + status + "' where ID='" + ID + "'";
                SqlCommand cmd = new SqlCommand(updateQuery, sqlCnt);
                sqlCnt.Open();
                int RecordsAffected = cmd.ExecuteNonQuery();
                if (RecordsAffected <= 0)
                {
                    rowcount = false;
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sqlCnt.Close();
                sqlCnt.Dispose();
            }
            return rowcount;
        }
        /// <summary>
        /// 搜索问题列表
        /// </summary>
        /// <param name="pid">产品ID</param>
        /// <param name="keyword">关键字</param>
        /// <returns></returns>
        public static DataTable GetQAList(int pid, string keyword)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            try
            {
                conn = new SqlConnection(connectionString);
                string sql = @"select a.Title,a.FilePath,a.Answer,a.VeevaID,a.Status
from Lilly_MedicalQA a inner join Lilly_Medicals b on a.MID = b.ID
inner join Lilly_Category c on a.CID=c.ID
inner join Lilly_TherapeuticAreas d on b.TID=d.ID
where a.Status=1 and a.MID = @MID and(b.Name like @keyword or b.Summary like @keyword 
or a.LocalKeyWord like @keyword or a.Title like @keyword or a.Answer like @keyword 
or c.Name like @keyword or c.EnglishName like @keyword or d.AreaName like @keyword)";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                SqlParameter para1 = new SqlParameter("@MID", SqlDbType.Int);
                para1.Value = pid;
                comm.Parameters.Add(para1);
                SqlParameter para2 = new SqlParameter("@keyword",SqlDbType.VarChar);
                para2.Value = "%" + keyword + "%";
                comm.Parameters.Add(para2);
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(comm);
                conn.Open();
                DataTable result = new DataTable();
                sqlDataAdapter.Fill(result);
                return result;
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }
        /// <summary>
        /// 执行SQL语句
        /// </summary>
        /// <param name="sql">要执行的完整SQL语句</param>
        public static void ExecuteNonQuery(string sql)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            try
            {
                conn = new SqlConnection(connectionString);
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(comm);
                conn.Open();
                comm.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                conn.Close();
            }
        }

        /// <summary>
        /// 执行SQL查询语句
        /// </summary>
        /// <param name="sql"></param>
        /// <returns></returns>
        public static DataTable ExecuteQuery(string sql)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            try
            {
                conn = new SqlConnection(connectionString);
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(comm);
                conn.Open();
                DataTable result = new DataTable();
                sqlDataAdapter.Fill(result);
                return result;
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }
        /// <summary>
        /// 根据产品ID获取产品说明书
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public static List<LillyMedical.Model.DBModel.Lilly_BookLinks> GetBookLinksByMID(int id)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                string sql = "select * from Lilly_BookLinks where MID="+id.ToString();
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(comm);
                conn.Open();
                sdreader = comm.ExecuteReader();
                List<LillyMedical.Model.DBModel.Lilly_BookLinks> result = new List<Model.DBModel.Lilly_BookLinks>();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_BookLinks bookLink= new Model.DBModel.Lilly_BookLinks();
                    bookLink.ID = Convert.ToInt32(sdreader["ID"]);
                    bookLink.MID = Convert.ToInt32(sdreader["MID"]);
                    bookLink.Name = Convert.ToString(sdreader["Name"]);
                    bookLink.BookLink = Convert.ToString(sdreader["BookLink"]);
                    result.Add(bookLink);
                }
                return result;
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                conn.Close();
            }
            return null;
        }

        /// <summary>
        /// 存储问答数据
        /// </summary>
        /// <param name="html"></param>
        /// <returns></returns>
        public static void AnswerHandler(string id, string content)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            try
            {
                conn = new SqlConnection(connectionString);
                string sql = "update Lilly_MedicalQA set Answer=@answer where id=@id";
                comm = new SqlCommand(sql);
                SqlParameter sp1 = new SqlParameter("@id", id);
                comm.Parameters.Add(sp1);
                SqlParameter sp2 = new SqlParameter("@answer", content);
                comm.Parameters.Add(sp2);
                comm.Connection = conn;
                conn.Open();
                comm.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                conn.Close();
            }
        }
        /// <summary>
        /// 记录后台管理员操作日志
        /// </summary>
        /// <param name="log"></param>
        public static void RecordUserLog(LillyMedical.Model.DBModel.Lilly_UserLogs log)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "insert into Lilly_UserLogs(ID,Stamp,UserAccount,LogDetails) select NEWID(),GETDATE(),@UserAccount,@LogDetail";
                comm = new SqlCommand(sql);
                comm.Connection = conn;
                comm.CommandType = CommandType.Text;
                SqlParameter para1 = new SqlParameter("@UserAccount", SqlDbType.VarChar);
                para1.Value = log.UserAccount;
                comm.Parameters.Add(para1);
                SqlParameter para2 = new SqlParameter("@LogDetail", SqlDbType.VarChar);
                para2.Value = log.LogDetails;
                comm.Parameters.Add(para2);
                comm.ExecuteNonQuery();
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                conn.Close();
            }
        }

        /// <summary>
        /// VeevaID唯一性验证
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="VeevaID"></param>
        /// <returns></returns>
        public static bool ValVeevaID(string Id, string VeevaID)
        {
            bool flag = false;
            SqlConnection conn = null;
            SqlCommand comm = null;
            try
            {
                conn = new SqlConnection(connectionString);
                string sql = "select * from Lilly_MedicalQA where VeevaID=@VeevaUD and ID<>@Id ";
                comm = new SqlCommand(sql);
                SqlParameter para1 = new SqlParameter("@VeevaUD", SqlDbType.VarChar);
                para1.Value = VeevaID;
                comm.Parameters.Add(para1);
                SqlParameter para2 = new SqlParameter("@Id", SqlDbType.Int);
                para2.Value = Id == "" ? "0" : Id;
                comm.Parameters.Add(para2);
                comm.Connection = conn;
                SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(comm);
                conn.Open();
                DataTable result = new DataTable();
                sqlDataAdapter.Fill(result);
                if (result.Rows.Count == 0)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
                flag = false;
            }
            finally
            {
                conn.Close();
            }
            return flag;
        }

        /// <summary>
        /// 根据VeevaID获取QA信息
        /// </summary>
        /// <param name="VeevaID"></param>
        /// <returns></returns>
        public static LillyMedical.Model.DBModel.Lilly_MedicalQA GetQAByVeevaID(string VeevaID)
        {
            SqlConnection conn = null;
            SqlCommand comm = null;
            SqlDataReader sdreader = null;
            try
            {
                conn = new SqlConnection(connectionString);
                conn.Open();
                string sql = "select * from Lilly_MedicalQA where VeevaID=@VeevaID";
                comm = new SqlCommand(sql);
                SqlParameter para = new SqlParameter("@VeevaID", SqlDbType.VarChar);
                para.Value = VeevaID;
                comm.Parameters.Add(para);
                comm.Connection = conn;
                sdreader = comm.ExecuteReader();
                while (sdreader.Read())
                {
                    LillyMedical.Model.DBModel.Lilly_MedicalQA qa = new Model.DBModel.Lilly_MedicalQA();
                    qa.ID = Convert.ToInt32(sdreader["ID"]);
                    qa.MID = Convert.ToInt32(sdreader["MID"]);
                    qa.CID = Convert.ToInt32(sdreader["CID"]);
                    qa.LocalKeyWord = Convert.ToString(sdreader["LocalKeyWord"]);
                    qa.SEOKeyWord = Convert.ToString(sdreader["SEOKeyWord"]);
                    qa.Title = Convert.ToString(sdreader["Title"]);
                    qa.Answer = Convert.ToString(sdreader["Answer"]);
                    qa.FilePath = Convert.ToString(sdreader["FilePath"]);
                    qa.Status = Convert.ToBoolean(sdreader["Status"]);
                    qa.VeevaID = Convert.ToString(sdreader["VeevaID"]);
                    qa.Description = Convert.ToString(sdreader["Description"]);
                    return qa;
                }
            }
            catch (SqlException ex)
            {
                LogFileHandler.WriteLog(ex);
            }
            finally
            {
                sdreader.Close();
                conn.Close();
            }
            return null;
        }
    }
}