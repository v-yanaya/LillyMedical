﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace LillyMedical.Utility
{
    /// <summary>
    /// Log文件处理类
    /// </summary>
    public class LogFileHandler
    {
        /// <summary>
        /// 将异常打印到LOG文件
        /// </summary>
        /// <param name="ex">异常</param>
        /// <param name="LogAddress">日志文件地址</param>
        public static void WriteLog(Exception ex)
        {
            try
            {
                string LogAddress = GetWebRootPath() + @"\\logs\\" + DateTime.Now.ToString("yyyy-MM-dd") + "_Log.txt";
                using (FileStream fs = new FileStream(LogAddress, FileMode.Append))
                {
                    StringBuilder content = new StringBuilder();
                    content.AppendLine("==========================================================================================");
                    content.AppendLine("当前时间：" + DateTime.Now.ToString());
                    content.AppendLine("异常信息：" + ex.Message);
                    content.AppendLine("异常对象：" + ex.Source);
                    content.AppendLine("调用堆栈：\n" + ex.StackTrace.Trim());
                    content.AppendLine("触发方法：" + ex.TargetSite);

                    //获得字节数组
                    byte[] dataByte = Encoding.Default.GetBytes(content.ToString());
                    //开始写入
                    fs.Write(dataByte, 0, content.Length);
                    fs.Flush();
                    fs.Close();
                    fs.Dispose();
                }
            }
            catch (Exception exception)
            {
                //WriteLog(exception);
            }
            finally
            {
                //清空缓冲区、关闭流
            }
        }
        /// <summary>
        /// 记录SSO Response
        /// </summary>
        /// <param name="file"></param>
        public static void RecordSAMLMeta(string file)
        {
            try
            {
                string LogAddress = GetWebRootPath() + @"\\logs\\" + DateTime.Now.ToString("yyyy-MM-dd") + "_saml.txt";
                using (FileStream fs = new FileStream(LogAddress, FileMode.Append))
                {
                    StringBuilder content = new StringBuilder();
                    content.AppendLine("==========================================================================================");
                    content.AppendLine("当前时间：" + DateTime.Now.ToString());
                    content.AppendLine(file);
                    //获得字节数组
                    byte[] dataByte = Encoding.Default.GetBytes(content.ToString());
                    //开始写入
                    fs.Write(dataByte, 0, dataByte.Length);
                    fs.Flush();
                    fs.Close();
                    fs.Dispose();
                }
            }
            catch (Exception exception)
            {
                WriteLog(exception);
            }
            finally
            {
                
            }
        }

        /// <summary>
        /// 获取当前网站根目录
        /// </summary>
        /// <returns></returns>
        public static string GetWebRootPath()
        {
            string AppPath = "";
            HttpContext HttpCurrent = HttpContext.Current;
            if (HttpCurrent != null)
            {
                AppPath = HttpCurrent.Server.MapPath("~");
            }
            else
            {
                AppPath = AppDomain.CurrentDomain.BaseDirectory;
                if (Regex.Match(AppPath, @"\\$", RegexOptions.Compiled).Success)
                    AppPath = AppPath.Substring(0, AppPath.Length - 1);
            }
            return AppPath;
        }
        /// <summary>
        /// 判断日志文件是否被其他线程占用
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public static bool IsFileInUse(string fileName)
        {
            bool inUse = true;
            FileStream fs = null;
            try
            {
                fs = new FileStream(fileName, FileMode.Open, FileAccess.Read,FileShare.None);
                inUse = false;
            }
            catch
            {

            }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                }
            }
            return inUse;//true表示正在使用,false没有使用
        }

        /// <summary>
        /// 记录后台管理员操作日志
        /// </summary>
        /// <param name="log"></param>
        public static void RecordUserLog(LillyMedical.Model.DBModel.Lilly_UserLogs log)
        {
            DBHelper.RecordUserLog(log);
        }
    }
}