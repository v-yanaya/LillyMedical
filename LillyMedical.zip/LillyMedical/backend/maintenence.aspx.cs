﻿using LillyMedical.Utility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LillyMedical.backend
{
    public partial class maintenence : System.Web.UI.Page
    {
        public static string QAContent=string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindProductList();
                BindCategoryList();
                string qaID = Server.UrlDecode(Request.QueryString["id"]);
                if (!string.IsNullOrEmpty(qaID))
                {
                    InitPageField(qaID);
                }
                hdf_preview_src.Value = "";
            }
        }
        /// <summary>
        /// 绑定产品下拉框
        /// </summary>
        public void BindProductList()
        {
            List<LillyMedical.Model.DBModel.Lilly_Medicals> list = Utility.BusinessHelper.GetAllMedecials();
            ListItem def = new ListItem("请选择产品");
            def.Selected = true;
            ddl_product.Items.Add(def);
            foreach (LillyMedical.Model.DBModel.Lilly_Medicals medical in list)
            {
                ListItem item = new ListItem(medical.Name.Replace("<sup>&#174;</sup>", ""), medical.ID.ToString());//®
                ddl_product.Items.Add(item);
            }
        }
        /// <summary>
        /// 绑定Category下拉框
        /// </summary>
        public void BindCategoryList()
        {
            List<LillyMedical.Model.DBModel.Lilly_Category> list = Utility.BusinessHelper.GetAllCategory();
            ListItem def = new ListItem("请选择Category");
            def.Selected = true;
            ddl_category.Items.Add(def);
            foreach (LillyMedical.Model.DBModel.Lilly_Category category in list)
            {
                ListItem item = new ListItem(category.Name, category.ID.ToString());
                ddl_category.Items.Add(item);
            }
        }
        /// <summary>
        /// 发布按钮点击事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (UserHelper.CurrentLoginUserInfo == null)
                {
                    Response.Redirect("../files/time_out.html");
                }
                Model.DBModel.Lilly_MedicalQA qa = null;
                string oldFilePath = string.Empty;
                if (hdf_id.Value == "")
                {
                    qa = new Model.DBModel.Lilly_MedicalQA();
                }
                else
                {
                    qa = LillyMedical.Utility.BusinessHelper.GetMedicalQAByID(hdf_id.Value);
                    oldFilePath = qa.FilePath;
                }
                qa.MID = Convert.ToInt32(ddl_product.SelectedValue);
                qa.CID = Convert.ToInt32(ddl_category.SelectedValue);
                qa.LocalKeyWord = txt_keyworkd.Text;
                qa.SEOKeyWord = "";
                qa.Title = txt_title.Text;
                qa.VeevaID = txt_VeevaID.Text.Trim();
                qa.Description = txt_description.Text.Trim();
                if (!ValVeevaID(qa.ID.ToString(), qa.VeevaID))
                {
                    Response.Write("<script type='text/javascript'>alert('VeevaID不唯一, 请修改')</script>");
                    return;
                }
                //将文件保存在服务器中根目录下的files文件夹中
                string guid = Guid.NewGuid().ToString();
                string newFile = LillyMedical.Utility.LogFileHandler.GetWebRootPath() + "\\files\\qa_instance\\" + guid + ".html";
                
                string templateFile = LillyMedical.Utility.LogFileHandler.GetWebRootPath() + "\\files\\" + "qa_template.html";
                
                string templateContent = File.ReadAllText(templateFile);
                LillyMedical.Model.DBModel.Lilly_Medicals medical = LillyMedical.Utility.BusinessHelper.GetMedicalByID(Convert.ToInt32(ddl_product.SelectedItem.Value));

                #region 导航栏参数与seo字段
                LillyMedical.Model.DBModel.Lilly_Medicals product = BusinessHelper.QueryProduct(" ID='" + ddl_product.SelectedItem.Value + "'");
                LillyMedical.Model.DBModel.Lilly_TherapeuticAreas area = BusinessHelper.QueryAreas(" ID='" + product.TID + "'");

                templateContent = templateContent.Replace("{seotitle}", qa.Title.Trim());
                templateContent = templateContent.Replace("{areapath}", area.URLPath);
                templateContent = templateContent.Replace("{areaname}", area.AreaName);
                templateContent = templateContent.Replace("{productpath}", product.URLPath);
                #endregion
                templateContent = templateContent.Replace("{title}", BusinessHelper.FormatTradeMark(qa.Title));
                templateContent = templateContent.Replace("{productname}", ddl_product.SelectedItem.Text.Replace("（", "<sup>&#174;</sup>（"));
                templateContent = templateContent.Replace("{category}", ddl_category.SelectedItem.Text);
                templateContent = templateContent.Replace("{seokeyword}", qa.LocalKeyWord.Trim());
                string description = "本文旨在为医疗卫生专业人士提供关于{0}的信息。";
                string commonname = product.Name.Substring(product.Name.IndexOf('（') + 1, product.Name.IndexOf('）') - product.Name.IndexOf('（') - 1);
                templateContent = templateContent.Replace("{seodescription}", string.Format(description, commonname));
                templateContent = templateContent.Replace("{description}", BusinessHelper.FormatTradeMark(qa.Description));
                //说明书部分
                string ol = "<ol>";
                foreach (LillyMedical.Model.DBModel.Lilly_BookLinks bookLink in LillyMedical.Utility.BusinessHelper.GetBookLinksByMID(Convert.ToInt32(ddl_product.SelectedValue)))
                {
                    ol += "<li>";
                    ol += ("<a href='" + bookLink.BookLink + "'>" + bookLink.Name + "</a>");
                    ol += "</li>";
                }
                ol += "</ol>";
                templateContent = templateContent.Replace("{booklink}", ol);
                
                qa.FilePath = newFile;
                hdf_src.Value = "../files/qa_instance/" + guid + ".html?from=self";
                
                string QAContent = ReadAnswerFromFileUpload();
                //回答信息
                string qaanswer = LillyMedical.Utility.BusinessHelper.BodyHandler(QAContent);
                templateContent = templateContent.Replace("{qaanswer}", qaanswer);
                hdf_answer.Value = qaanswer;
                //样式信息
                string style = LillyMedical.Utility.BusinessHelper.StyleHandler(QAContent);
                templateContent = templateContent.Replace("{style}", style);
                //药品使用
                string drug_license = "";
                if (medical.ShowDrugLicense)
                {
                    drug_license = "<div class='hejiLogo'></div>";
                }
                templateContent = templateContent.Replace("{drug_license}", drug_license);
                
                LillyMedical.Model.DBModel.Lilly_UserLogs log = new Model.DBModel.Lilly_UserLogs();
                log.UserAccount = UserHelper.CurrentLoginUserInfo.GlobalID;
                if (string.IsNullOrEmpty(log.UserAccount))
                {
                    log.UserAccount = UserHelper.CurrentLoginUserInfo.displayname;
                }
                if (hdf_id.Value == "")
                {
                    int id = Utility.BusinessHelper.AddMedicalQA(qa);
                    qa.ID = id;
                    hdf_id.Value = id.ToString();
                    log.LogDetails = "新增问答 "+qa.Title;
                }
                else
                {
                    Utility.BusinessHelper.UpdateMedicalQA(qa);
                    log.LogDetails = "修改问答信息 " + qa.Title;
                }
                LillyMedical.Utility.LogFileHandler.RecordUserLog(log);
                //ID
                templateContent = templateContent.Replace("{ID}", qa.ID.ToString());
                File.WriteAllText(newFile, templateContent);
                Response.Write("<div id='maskLayer' class='maskLayer'></div>");
                Response.Write("<div id ='popWindow' class='popWindow'>");
                Response.Write("<div style = 'font-weight:bold; font-size:larger; margin-top:10px'> 发布成功！！</div>");
                Response.Write("<div style = 'margin-top:10px;'><input type='button' style='background-color:#D52B1E;width:60px; height:30px;' value='关闭' onclick='closeMaskLayer();'/></div>");
                Response.Write("</div>");
                hdf_scrollbar.Value = "0";
                if (File.Exists(oldFilePath.Replace("\\", @"\")))
                {
                    File.Delete(oldFilePath.Replace("\\", @"\"));
                }
            }
            catch (Exception ex)
            {
                LogFileHandler.WriteLog(ex);
            }
        }
        /// <summary>
        /// 保存临时文件
        /// </summary>
        /// <returns></returns>
        [WebMethod]
        public string SaveTempFile()
        {
            string fullFileName = fupd_HTML.PostedFile.FileName;
            //从路径中截取出文件名        
            string fileName = fullFileName.Substring(fullFileName.LastIndexOf('\\') + 1);
            //限定上传文件的格式        
            string type = fullFileName.Substring(fullFileName.LastIndexOf('.') + 1);
            if (type == "html")
            {
                //将文件保存在服务器中根目录下的files文件夹中            
                string saveFileName = LillyMedical.Utility.LogFileHandler.GetWebRootPath() + "\\temp\\" + fileName;
                fupd_HTML.PostedFile.SaveAs(saveFileName);
                return "../temp/" + fileName;
            }
            else
            {
                Response.Write("<script type='text/javascript'>alert('只能上传html格式文件!!')</script>");
                return string.Empty;
            }
        }
                
        /// <summary>
        /// 根据QA ID初始化页面字段值
        /// </summary>
        /// <param name="id"></param>
        public void InitPageField(string id)
        {
            LillyMedical.Model.DBModel.Lilly_MedicalQA qa = LillyMedical.Utility.BusinessHelper.GetMedicalQAByID(id);
            if (qa != null)
            {
                hdf_id.Value = qa.ID.ToString();
                if (qa.FilePath != null)
                {
                    int idx = qa.FilePath.LastIndexOf('\\');
                    hdf_src.Value = "../files/qa_instance/" + qa.FilePath.Substring(idx + 1)+"?from=self";
                }
                txt_VeevaID.Text = qa.VeevaID;
                txt_description.Text = qa.Description;
                LillyMedical.Model.DBModel.Lilly_Medicals medical = LillyMedical.Utility.BusinessHelper.GetMedicalByID(qa.MID);
                if (medical != null)
                {
                    txt_title.Text = qa.Title;
                    txt_keyworkd.Text = qa.LocalKeyWord;
                }
                foreach (ListItem item in ddl_product.Items)
                {
                    item.Selected = false;
                }
                foreach (ListItem item in ddl_product.Items)
                {
                    if (item.Value == qa.MID.ToString())
                    {
                        item.Selected = true;
                        break;
                    }
                }
                foreach (ListItem item in ddl_category.Items)
                {
                    item.Selected = false;
                }
                foreach (ListItem item in ddl_category.Items)
                {
                    if (item.Value == qa.CID.ToString())
                    {
                        item.Selected = true;
                        break;
                    }
                }
            }
        }
        [WebMethod]
        public static string ShowIframe(string id)
        {
            LillyMedical.Model.DBModel.Lilly_MedicalQA qa = LillyMedical.Utility.BusinessHelper.GetMedicalQAByID(id);
            if (qa != null)
            {
                int idx = qa.FilePath.LastIndexOf('\\');
                return "../files/qa_instance/" + qa.FilePath.Substring(idx + 1)+"?from=self";
            }
            return string.Empty;
        }
        /// <summary>
        /// 更新QA Answer
        /// </summary>
        /// <param name="id"></param>
        /// <param name="content"></param>
        [WebMethod]
        public static void UpdateQAContent(string id,string content)
        {
            LillyMedical.Utility.BusinessHelper.AnswerHandler(id, content);
        }
        /// <summary>
        /// 预览按钮点击事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void btnPreview_Click(object sender, EventArgs e)
        {
            try
            {
                //将文件保存在服务器中根目录下的files文件夹中
                string guid = Guid.NewGuid().ToString();
                string previewFile = LillyMedical.Utility.LogFileHandler.GetWebRootPath() + "\\files\\preview\\" + guid + ".html";
                string templateFile = LillyMedical.Utility.LogFileHandler.GetWebRootPath() + "\\files\\" + "qa_template.html";
                string templateContent = File.ReadAllText(templateFile);
                LillyMedical.Model.DBModel.Lilly_Medicals product = BusinessHelper.QueryProduct(" ID='" + ddl_product.SelectedItem.Value + "'");
                LillyMedical.Model.DBModel.Lilly_Medicals medical = LillyMedical.Utility.BusinessHelper.GetMedicalByID(Convert.ToInt32(ddl_product.SelectedItem.Value));
                LillyMedical.Model.DBModel.Lilly_TherapeuticAreas area = BusinessHelper.QueryAreas(" ID='" + product.TID + "'");
                templateContent = templateContent.Replace("{seotitle}", BusinessHelper.FormatTradeMark(txt_title.Text.Trim()));
                templateContent = templateContent.Replace("{areapath}", area.URLPath);
                templateContent = templateContent.Replace("{areaname}", area.AreaName);
                templateContent = templateContent.Replace("{productpath}", product.URLPath);

                templateContent = templateContent.Replace("{title}", BusinessHelper.FormatTradeMark(txt_title.Text));
                templateContent = templateContent.Replace("{productname}", ddl_product.SelectedItem.Text.Replace("（", "<sup>&#174;</sup>（"));
                templateContent = templateContent.Replace("{category}", ddl_category.SelectedItem.Text);
                templateContent = templateContent.Replace("{seokeyword}", txt_keyworkd.Text.Trim());
                string description = "本文旨在为医疗卫生专业人士提供关于{0}的信息。";
                string commonname = product.Name.Substring(product.Name.IndexOf('（') + 1, product.Name.IndexOf('）') - product.Name.IndexOf('（') - 1);
                templateContent = templateContent.Replace("{seodescription}", string.Format(description, commonname));
                templateContent = templateContent.Replace("{description}", BusinessHelper.FormatTradeMark(txt_description.Text.Trim()));
                //说明书部分
                string ol = "<ol>";
                foreach (LillyMedical.Model.DBModel.Lilly_BookLinks bookLink in LillyMedical.Utility.BusinessHelper.GetBookLinksByMID(Convert.ToInt32(ddl_product.SelectedValue)))
                {
                    ol += "<li>";
                    ol += ("<a href='" + bookLink.BookLink + "'>" + bookLink.Name + "</a>");
                    ol += "</li>";
                }
                ol += "</ol>";
                templateContent = templateContent.Replace("{booklink}", ol);
                //回答信息
                string QAContent = ReadAnswerFromFileUpload();                    
                string qaanswer = LillyMedical.Utility.BusinessHelper.BodyHandler(QAContent);
                templateContent = templateContent.Replace("{qaanswer}", qaanswer);
                //样式信息
                string style = LillyMedical.Utility.BusinessHelper.StyleHandler(QAContent);
                templateContent = templateContent.Replace("{style}", style);
                //ID
                templateContent = templateContent.Replace("{ID}", "preview");
                //药品使用
                string drug_license = "";
                if (medical.ShowDrugLicense)
                {
                    drug_license = "<div class='hejiLogo'></div>";
                }
                templateContent = templateContent.Replace("{drug_license}", drug_license);
                File.WriteAllText(previewFile, templateContent);
                hdf_preview_src.Value = "../files/preview/" + guid + ".html?from=self";
            }
            catch (Exception ex)
            {
                LogFileHandler.WriteLog(ex);
            }
        }
        /// <summary>
        /// 读取上传文件按钮中的文件内容
        /// </summary>
        /// <returns></returns>
        protected string ReadAnswerFromFileUpload()
        {
            string result = String.Empty;
            if (fupd_HTML.HasFile)
            {
                int FileLen = fupd_HTML.PostedFile.ContentLength;//获取上传文件的大小
                byte[] input = new byte[FileLen];
                System.IO.Stream UpLoadStream = fupd_HTML.PostedFile.InputStream;
                UpLoadStream.Read(input, 0, FileLen);
                UpLoadStream.Position = 0;
                System.IO.StreamReader sr = new System.IO.StreamReader(UpLoadStream, System.Text.Encoding.UTF8);
                result = sr.ReadToEnd();
                sr.Close();
                UpLoadStream.Close();
                UpLoadStream = null;
                sr = null;
                QAContent = result;
            }
            else
            {
                result = QAContent;
            }
            return result;
        }
        /// <summary>
        /// 根据ID，判断当前QA的状态
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        [WebMethod]
        public static string DecideQAStatus(string ID)
        {
            LillyMedical.Model.DBModel.Lilly_MedicalQA qa = LillyMedical.Utility.BusinessHelper.GetMedicalQAByID(ID);
            if (qa == null)
            {
                return "问答信息不存在，无法查看";
            }
            if (!qa.Status)
            {
                return "问答信息已下架，无法查看";
            }
            return "";
        }
        /// <summary>
        /// VeevaID 唯一性验证
        /// </summary>
        /// <param name="Id"></param>
        /// <param name="VeevaID"></param>
        /// <returns></returns>
        [WebMethod]
        public static bool ValVeevaID(string Id,string VeevaID)
        {
            return BusinessHelper.ValVeevaID(Id, VeevaID);
        }
    }
}
