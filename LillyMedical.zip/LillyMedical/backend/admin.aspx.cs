﻿using LillyMedical.Utility;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LillyMedical.backend
{
    public partial class admin : System.Web.UI.Page
    {
        public const string AttributesSessionKey = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        [WebMethod]
        public static string GetLilly_TherapeuticAreas()
        {
            //获取所有领域信息
            List<Model.DBModel.Lilly_TherapeuticAreas> result = BusinessHelper.GetAllAreas();
            StringBuilder innerHTML = new StringBuilder();

            if (result.Count > 0)
            {
                innerHTML.Append("<option value='0'>请选择</option>");
                foreach (var item in result)
                {
                    innerHTML.Append("<option value='" + item.ID + "'>" + item.AreaName + "</option>");
                }
            }
            return innerHTML.ToString();
        }

        [WebMethod]
        public static string GetLilly_MedicalsByTID(int TID)
        {
            //根据领域TID获取所属所有药品产品信息
            List<Model.DBModel.Lilly_Medicals> result = BusinessHelper.AllMedicals(" TID =" + TID + "");
            StringBuilder innerHTML = new StringBuilder();

            innerHTML.Append("<option value='0'>请选择</option>");
            if (result.Count > 0)
            {
                foreach (var item in result)
                {
                    innerHTML.Append("<option value='" + item.ID + "'>" + item.Name + "</option>");
                }
            }
            return innerHTML.ToString();
        }
        [WebMethod]
        public static string GetLilly_Medicals()
        {
            //获取所有药品产品信息
            List<Model.DBModel.Lilly_Medicals> result = BusinessHelper.GetAllMedecials();
            StringBuilder innerHTML = new StringBuilder();

            innerHTML.Append("<option value='0'>请选择</option>");
            if (result.Count > 0)
            {
                foreach (var item in result)
                {
                    innerHTML.Append("<option value='" + item.ID + "'>" + item.Name + "</option>");
                }
            }
            return innerHTML.ToString();
        }

        [WebMethod]
        public static void CancelClick()
        {
            LillyMedical.Utility.UserHelper.CurrentLoginUserInfo = null;
        }
        [WebMethod]
        public static string GetLilly_MedicalsList(int status, int areas, int product,int category,string veevaid,string qatitle)
        {
            List<Model.PageModel.qa_adminpage> result = BusinessHelper.Lilly_MedicalQAList(status, areas, product, category, veevaid, qatitle);
            return Newtonsoft.Json.JsonConvert.SerializeObject(result);
        }

        [WebMethod]
        public static bool UpdateMedicalQAStatus(int Status, int QAid)
        {
            bool result = BusinessHelper.UpdateMedicalQAStatus(QAid, Status);
            return result;
        }
        [WebMethod]
        public static string ShowIframe(string id)
        {
            LillyMedical.Model.DBModel.Lilly_MedicalQA qa = LillyMedical.Utility.BusinessHelper.GetMedicalQAByID(id);
            if (qa != null)
            {
                int idx = qa.FilePath.LastIndexOf('\\');
                return "../files/qa_instance/" + qa.FilePath.Substring(idx + 1) + "?from=self";
            }
            return string.Empty;
        }
        /// <summary>
        /// 更新QA Answer
        /// </summary>
        /// <param name="id"></param>
        /// <param name="content"></param>
        [WebMethod]
        public static void UpdateQAContent(string id, string content)
        {
            LillyMedical.Utility.BusinessHelper.AnswerHandler(id, content);
        }

        [WebMethod]
        public static string GetCategoryList()
        {
            //获取所有Category信息
            List<Model.DBModel.Lilly_Category> result = BusinessHelper.GetAllCategory();
            StringBuilder innerHTML = new StringBuilder();
            if (result.Count > 0)
            {
                innerHTML.Append("<option value='0'>请选择</option>");
                foreach (var item in result)
                {
                    innerHTML.Append("<option value='" + item.ID + "'>" + item.Name + "</option>");
                }
            }
            return innerHTML.ToString();
        }
    }
}