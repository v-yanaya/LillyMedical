﻿using LillyMedical.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LillyMedical.backend
{
    public partial class userinfo1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (UserHelper.CurrentLoginUserInfo == null)
            {
                Response.Redirect("../files/time_out.html");
            }
            else if (!LillyMedical.master.admin.IsSystemAdmin)
            {
                Response.Redirect("../files/no-access.html");
            }
        }
        [WebMethod]
        public static string GetUserInfo(string id)
        {
            string sql = "select * from Lilly_RoleUsers where id={0}";
            sql = string.Format(sql, id);
            System.Data.DataTable table = LillyMedical.Utility.BusinessHelper.ExecuteQuery(sql);
            LillyMedical.Model.DBModel.Lilly_RoleUsers user = new Model.DBModel.Lilly_RoleUsers();
            if (table.Rows.Count > 0)
            {
                user.ID = Convert.ToInt32(table.Rows[0]["ID"]);
                user.RoleName = Convert.ToString(table.Rows[0]["RoleName"]);
                user.UserAccount = Convert.ToString(table.Rows[0]["UserAccount"]);
                user.UserName = Convert.ToString(table.Rows[0]["UserName"]);
                user.Status = Convert.ToBoolean(table.Rows[0]["Status"]);
            }
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(user);
            return json;
        }

        [WebMethod]
        public static void UpdateUserInfo(string id, string globalID, string userName, string roleName)
        {
            if (UserHelper.CurrentLoginUserInfo == null)
            {
                throw new Exception("Session Time Out");
            }
            string sql = "";
            if (id == "")
            {
                sql = string.Format("insert into Lilly_RoleUsers (RoleName,UserAccount,UserName,Status) select '{0}','{1}','{2}',1", roleName, globalID, userName);
            }
            else
            {
                sql = string.Format("update Lilly_RoleUsers set RoleName='{0}',UserAccount='{1}',UserName='{2}' where ID={3}", roleName, globalID, userName, id);
            }
            LillyMedical.Utility.BusinessHelper.ExecuteNonQuery(sql);
        }
    }
}