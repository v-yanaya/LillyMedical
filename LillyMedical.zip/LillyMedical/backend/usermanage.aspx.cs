﻿using LillyMedical.Utility;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace LillyMedical.backend
{
    public partial class usermanage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (UserHelper.CurrentLoginUserInfo == null)
            {
                Response.Redirect("../files/time_out.html");
            }
            else if (!LillyMedical.master.admin.IsSystemAdmin)
            {
                Response.Redirect("../files/no-access.html");
            }
        }
        [WebMethod]
        public static string GetAllUsers()
        {
            List<Model.DBModel.Lilly_RoleUsers> result = BusinessHelper.GetAllUsers();
            return Newtonsoft.Json.JsonConvert.SerializeObject(result);
        }
        /// <summary>
        /// 删除操作
        /// </summary>
        /// <param name="id"></param>
        [WebMethod]
        public static void DeleteAction(string id)
        {
            if (UserHelper.CurrentLoginUserInfo == null)
            {
                throw new Exception("Session Time Out");
            }
            string sql = "delete Lilly_RoleUsers where ID='{0}'";
            sql = string.Format(sql, id);
            BusinessHelper.ExecuteNonQuery(sql);
        }
        /// <summary>
        /// 启用 禁用操作
        /// </summary>
        /// <param name="id"></param>
        /// <param name="Status"></param>
        [WebMethod]
        public static void UpdateStatus(string id,string Status)
        {
            if (UserHelper.CurrentLoginUserInfo == null)
            {
                throw new Exception("Session Time Out");
            }
            string sql = "update Lilly_RoleUsers set Status={0} where ID={1}";
            sql = string.Format(sql, Status, id);
            BusinessHelper.ExecuteNonQuery(sql);
        }
    }
}