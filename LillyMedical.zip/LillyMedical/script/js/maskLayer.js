﻿    var isUndefined = function (target) {
        return typeof (target) === 'undefined';
    };

    var isString = function (target) {
        return !isUndefined(target) && target.constructor === String;
    };

    var isObject = function (target) {
        return !isUndefined(target) && target.constructor === Object;
    };

    var args = {
        width: 600,     //该蒙板宽度，默认600，可不传该参数
        height: 400,    //该蒙板高度，默认400，可不传该参数
        title: {
            innerText: '欢迎访问礼来医学网',                  //标题层的内容文本（不支持HTML元素标签），默认''
            height: 20,                     //标题层高度，默认20
            backgroundColor: '#B0C4DE',      //标题层背景色，默认'#B0C4DE'
            hasCloseButton: false      //标题层是否需要关闭按钮用于关闭该蒙板，不传入该参数或其值为false则无关闭按钮
        },              //该蒙板标题层,可不传该参数（在不需要标题情况下）
        innerHTML: '<div></div>'   //该蒙板内容层文本（支持HTML元素标签），如果为undefined、null、'',则lillySoft.medical.maskLayer对象将不可用
    };

    var existsArgs = !isUndefined(args) && isString(args.innerHTML);    //是否存在所必须的传入的参数
    var needTitle = existsArgs && isObject(args.title);  //是否需要标题
    

    var that = this,
    var get$ = document.getElementById;
    var ids = {
        backgroundLayer: "divMaskLayerBackground",
        contentLayer: "divMaskLayerContent",
        titleLayer: "divMaskLayerTitle",
        textLayer: "divMaskLayerText",
        closeButton: "divCloseMaskLayer"
    };

    var isEmptyArray = function (target) {
        return isUndefined(target) || target.constructor !== Array && target.length == 0;
    };

    var removeChild = function (target, childId) {
        if (!isUndefined(target) && !isUndefined(childId)) {
            if (isString(target)) {
                target = get$(target);
            }
            if (target) {
                var child = get$(childId);
                if (child) {
                    target.removeChild(child);
                }
            }
        }
    };

    //设置Document元素属性
    //target为Document元素
    //attrs为一个object数组
    //object中包含key、value两个属性，格式如：{ key: "id", value: "idvalue" }
    var setElmtAttrs = function (target, attrs) {
        if (isUndefined(target) || isUndefined(target.setAttribute) || isEmptyArray(attrs)) {
            return;
        }
        for (var i = 0; i < attrs.length; i++) {
            var attr = attrs[i];
            if (isString(attr.key) && !isUndefined(attr.value)) {
                target.setAttribute(attr.key, attr.value);
            }
        }
    };

    //设置Document元素样式
    //target为Document元素
    //style为Document.Elment.Style对象，根据自己需要添加相关属性，格式如：{ width: "100px", height: "100px", background: "#000000"，...... }
    var setElmtStyle = function (target, style) {
        if (isUndefined(target) || isUndefined(target.style) || isUndefined(style)) {
            return;
        }
        if (isString(style.position))
            target.style.position = style.position;
        if (isString(style.background))
            target.style.background = style.background;
        if (isString(style.border))
            target.style.border = style.border;
        if (isString(style.font))
            target.style.font = style.font;
        if (isString(style.filter))
            target.style.filter = style.filter;
        if (isString(style.opacity))
            target.style.opacity = style.opacity;
        if (isString(style.marginLeft))
            target.style.marginLeft = style.marginLeft;
        if (isString(style.marginTop))
            target.style.marginTop = style.marginTop;
        if (isString(style.left))
            target.style.left = style.left;
        if (isString(style.top))
            target.style.top = style.top;
        if (isString(style.width))
            target.style.width = style.width;
        if (isString(style.height))
            target.style.height = style.height;
        if (isString(style.textAlign))
            target.style.textAlign = style.textAlign;
        if (isString(style.lineHeight))
            target.style.lineHeight = style.lineHeight;
        if (isString(style.zIndex))
            target.style.zIndex = style.zIndex;
        if (isString(style.float))
            target.style.float = style.float;
        if (isString(style.fontWeight))
            target.style.fontWeight = style.fontWeight;
        if (isString(style.verticalAlign))
            target.style.verticalAlign = style.verticalAlign;
    };

    var createBackgroundLayer = function () {
        var bgLayer = document.createElement("div");
        var attrs = [{ key: "id", value: ids.backgroundLayer }];
        setElmtAttrs(bgLayer, attrs);
        var style = {
            position: "absolute",
            top: "0",
            background: "#777",
            filter: "Alpha(style=3,opacity=25,finishOpacity=75)",
            opacity: "0.7",
            left: "0",
            width: document.body.offsetWidth + "px",
            height: screen.height + "px",
            zIndex: "10000"
        };
        setElmtStyle(bgLayer, style);
        return bgLayer;
    };

    var createContentLayer = function () {
        var contentLayer = document.createElement("div")
        var attrs = [{ key: "id", value: ids.contentLayer },
        { key: "align", value: "center" }];
        setElmtAttrs(contentLayer, attrs);
        var style = {
            margin: "0",
            padding: "0",
            background: "white",
            border: "1px solid #B0C4DE",
            position: "absolute",
            left: (document.documentElement.clientWidth - args.width) / 2 + "px",
            top: (document.documentElement.clientHeight - args.height) / 2 + "px",
            width: args.width + "px",
            height: args.height + "px",
            textAlign: "center",
            zIndex: "10001"
        };
        setElmtStyle(contentLayer, style);
        return contentLayer;
    };

    var createTitleLayer = function () {
        var titleLayer = document.createElement("div");
        var attrs = [{ key: "id", value: ids.titleLayer },
                             { key: "align", value: "left"}];
        setElmtAttrs(titleLayer, attrs);
        var style = {
            padding: "0",
            margin: "0",
            background: args.title.backgroundColor,
            border: "1px solid " + args.title.backgroundColor,
            height: args.title.height + "px",
            color: "white",
            cursor: "pointer"
        };
        setElmtStyle(titleLayer, style);
        titleLayer.appendChild(createTitleLayerContent());
        return titleLayer;
    },

    var createTitleLayerContent = function () {
        var table = document.createElement("table");
        setElmtStyle(table, { width: "100%", textAlign: "left" });
        var row = table.insertRow(0);
        var textCell = row.insertCell();
        setElmtStyle(textCell, { fontWeight: "bold", verticalAlign: "middle" });
        textCell.innerText = args.title.innerText;

        //如果需要关闭按钮则创建关闭按钮
        if (args.title.hasCloseButton) {
            var closeBtnCell = row.insertCell();
            setElmtStyle(closeBtnCell, { width: "1%", textAlign: "right", verticalAlign: "top" });
            var closeButton = document.createElement("div");
            setElmtAttrs(closeButton, [{ id: "id", value: ids.closeButton }]);
            setElmtStyle(closeButton, { border: "1px solid black", width: "10px", height: "11px" });
            closeButton.innerText = "Ⅹ";
            closeButton.title = "关闭";
            closeButton.onclick = that.close;
            closeBtnCell.appendChild(closeButton);
        }
        return table;
    };

    var createTextLayer = function () {
        var text = document.createElement("div");
        text.setAttribute("id", ids.textLayer);
        text.innerHTML = args.innerHTML;
        return text;
    };

    //关闭蒙板
    var CloseMaskLayer = function () {
        removeChild(document.body, ids.backgroundLayer);
        if (needTitle) {
            removeChild(ids.contentLayer, ids.titleLayer);
        }
        removeChild(document.body, ids.contentLayer);
    };

    //打开蒙板
var OpenMaskLayer = function () {
    document.body.appendChild(createBackgroundLayer());
    content = createContentLayer();
    if (needTitle) {
        content.appendChild(createTitleLayer());
    }
    content.appendChild(createTextLayer());
    document.body.appendChild(content);
}