﻿insert into Lilly_RoleUsers
select '超级管理员','xuyang'
union all
select '业务管理员','xuyang'

insert into Lilly_TherapeuticAreas
select '糖尿病',1 union all
select '肿瘤',1 union all
select '自身免疫',1 union all
select '神经精神',0 union all
select '男性健康',0 union all
select '骨骼',0 

insert into Lilly_Category
select '用法用量','Dosage and Administration'
union all 
select '疗效','Efficacy'
union all 
select '安全性','Safety'
union all 
select '特殊人群及合并症','Patient Population/Coexisting Conditions'
union all 
select 'PK/PD','PK/PD'
union all 
select '储存及稳定性','Storage and Stability'
union all 
select '一般问题及其他','General/Other'

insert into Lilly_Medicals
select 1,N'度易达®（度拉糖肽注射液）','0.75 mg/0.5 mL, 1.5 mg/0.5 mL'
--union all
--select 1,N'优泌乐® U-100 (insulin lispro injection)','100 units/mL'
--union all
--select 1,N'优泌乐® U-200 (insulin lispro injection)','200 units/mL'
--union all
--select 1,N'优泌乐®MIX50/50™ ','100 units/mL'
--union all
--select 2,N'健择®(gemcitabine for injection)','200 mg in 10 mL vial; 1 gm in 50 mL vial'
--union all
--select 2,N'力比泰®(pemetrexed for injection)','100 mg and 500 mg vials'
union all
select 2,N'爱优特®（呋喹替尼胶囊）',''
union all
select 3,N'艾乐明®（巴瑞替尼片）','1mg, 2mg'
union all
select 3,N'拓咨®（依奇珠单抗注射液）','80 mg/mL'
--union all
--select 4,N'欣百达®Cymbalta',''
--union all
--select 4,N'百优解®PROZAC',''
--union all
--select 4,N'择思达®Strattera',''
--union all
--select 4,N'再普乐®Zyprexa',''
--union all
--select 5,N'希爱力® (tadalafil) tablets','2.5 mg, 5 mg, 10mg, 20 mg tablets'
--union all
--select 6,N'复泰奥® (teriparatide [rDNA origin] injection)','20-mcg daily dose in a 2.4-mL prefilled delivery device'
--union all
--select 6,N'易维特®  (raloxifene HCl) tablets  ','60 mg tablet'

insert into Lilly_BookLinks
select 31,'产品说明书','http://uspl.lilly.com/trulicity/trulicity.html'--度易达
--union all
--select 32,'产品说明书','http://uspl.lilly.com/humalog/humalog.html'
--union all
--select 33,'产品说明书','http://uspl.lilly.com/humalog/humalog.html'
--union all
--select 34,'产品说明书','http://uspl.lilly.com/humalog5050/humalog5050.html'
--union all
--select 35,'产品说明书','http://uspl.lilly.com/gemzar/gemzar.html'
--union all
--select 36,'产品说明书','http://uspl.lilly.com/alimta/alimta.html'
union all
select 38,'产品说明书','http://uspl.lilly.com/olumiant/olumiant.html#pi'--艾乐明
union all
select 39,'产品说明书','http://uspl.lilly.com/taltz/taltz.html'--拓咨
--union all
--select 45,'产品说明书','http://uspl.lilly.com/cialis/cialis.html'
--union all
--select 46,'产品说明书','http://uspl.lilly.com/forteo/forteo.html'
--union all
--select 47,'产品说明书','http://uspl.lilly.com/evista/evista.html'

insert into lilly_config
select 'time_interval',10