if exists(select * from sysobjects where id=object_id('sp_getclienteffective'))
begin
	drop proc sp_getclienteffective
end
go
create procedure sp_getclienteffective
@IPAddress varchar(20),
@URL varchar(100)
as
begin
	declare @stamp datetime,@id uniqueidentifier
	declare @newid uniqueidentifier
	set @newid=NEWID()
	declare @flag int,@ishcp int
	select top 1 @id=id,@stamp=Stamp,@ishcp=ishcp from Lilly_ClientLog where IPAddress=@IPAddress order by Stamp desc 
	declare @time_interval int
	select @time_interval=isnull(value,10) from lilly_config where name='time_interval'
	--������һ�ε�½�Ƿ�רҵ��ʿ���ʣ��򵯳���ӭ�Ի���
	if(ISNULL(@ishcp,0)=0)
	begin
		insert into Lilly_ClientLog
		select @newid,@IPAddress,@URL,GETDATE(),null
		select @flag=0
		select CAST(@newid as varchar(36))+'|'+CAST(@flag as varchar(1))
		return
	end
	if(@id is null)
	begin
		--��һ�η���
		insert into Lilly_ClientLog
		select @newid,@IPAddress,@URL,GETDATE(),null
		select @flag=0
	end
	else if(DATEADD(MI,@time_interval,@stamp)<=GETDATE())
	begin
		--������Чʱ�䣨10���ӣ�
		
		insert into Lilly_ClientLog
		select @newid,@IPAddress,@URL,GETDATE(),null
		select @flag=0
	end
	else
	begin
		--��Чʱ�䷶Χ��
		insert into Lilly_ClientLog
		select @newid,@IPAddress,@URL,GETDATE(),1
		select @flag=1
	end

	select CAST(@newid as varchar(36))+'|'+CAST(@flag as varchar(1))
end