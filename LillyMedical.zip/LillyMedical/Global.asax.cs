﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;

namespace LillyMedical
{
    public class Global : System.Web.HttpApplication
    {

        protected void Application_Start(object sender, EventArgs e)
        {
            
        }

        protected void Session_Start(object sender, EventArgs e)
        {
            
        }

        protected void Application_BeginRequest(object sender, EventArgs e)
        {
            try
            {
                string url = System.Web.HttpContext.Current.Request.Url.ToString().ToLower();
                if (url.StartsWith("http") && !url.StartsWith("https"))
                {
                    Response.Redirect(url.Replace("http", "https"));
                    return;
                }
                string dns_name = System.Configuration.ConfigurationManager.AppSettings["dns_name"].ToString();
                string global_name = dns_name.Replace("www.", "");
                if (!url.StartsWith("https://" + dns_name) && url.Contains("https://" + global_name))
                {
                    Response.Redirect(url.Replace(global_name, dns_name));
                    return;
                }
                string oldUrl = System.Web.HttpContext.Current.Request.RawUrl; //获取初始url 
                oldUrl = oldUrl.ToLower();
                if (oldUrl == "/")
                {
                    Response.Redirect(url + "zh-cn");
                    return;
                }
                #region 搜索结果页
                if (oldUrl.StartsWith("/front/searchresult.aspx?id="))
                {
                    return;
                }
                #endregion
                #region 后台管理员页面
                if (oldUrl.StartsWith("/backend/"))
                {
                    return;
                }
                #endregion
                #region 异步调用时不需要重写
                if (oldUrl.Contains(".aspx/"))
                {
                    return;
                }
                #endregion
                #region HomePage
                if (oldUrl == "/zh-cn")
                {
                    Context.RewritePath("~/front/index.aspx");
                    return;
                }
                #endregion
                string error_code = "";
                #region QA Page
                if (QALink(oldUrl,out error_code))
                {
                    if (error_code != "")
                    {
                        Response.Redirect("~/files/qa_issue?message=" + error_code);
                    }
                    return;
                }
                #endregion
                #region 底部导航栏
                if (FooterLink(oldUrl))
                {
                    return;
                }
                #endregion
                #region TaPage 和 ProductPage
                if (TaAndProduct(oldUrl))
                {
                    return;
                }
                #endregion
                #region 服务器控件调用
                if (oldUrl.Contains("webresource.axd"))
                {
                    return;
                }
                #endregion
                Response.Redirect("~/files/error_message.html?errorcode=1");
            }
            catch(Exception ex)
            {
                //LillyMedical.Utility.LogFileHandler.WriteLog(ex);
            }
        }

        protected bool FooterLink(string oldUrl)
        {
            //版权声明
            if (oldUrl == "/zh-cn/copyright.html")
            {
                Context.RewritePath("~/front/copyright.aspx");
                return true;
            }
            //使用条款
            if (oldUrl == "/zh-cn/terms-of-use.html")
            {
                Context.RewritePath("~/front/terms-of-use.aspx");
                return true;
            }
            //隐私声明
            if (oldUrl == "/zh-cn/privacy.html")
            {
                Context.RewritePath("~/front/privacy.aspx");
                return true;
            }
            //网站地图
            if (oldUrl == "/zh-cn/sitemap")
            {
                Context.RewritePath("~/front/sitemap.aspx");
                return true;
            }
            return false;
        }
        /// <summary>
        /// TaPage 和 ProductPage
        /// </summary>
        /// <param name="oldUrl"></param>
        /// <returns></returns>
        protected bool TaAndProduct(string oldUrl)
        {
            string sql = "select URLPath from Lilly_TherapeuticAreas where Enabled=1";
            DataTable ta = LillyMedical.Utility.BusinessHelper.ExecuteQuery(sql);
            if (ta.Rows.Count > 0)
            {
                for(int i = 0; i < ta.Rows.Count; i++)
                {
                    string URLPath = ta.Rows[i]["URLPath"].ToString();
                    if (oldUrl == "/zh-cn/" + URLPath)
                    {
                        Context.RewritePath("~/front/tapage.aspx?URLPath="+ URLPath);
                        return true; ;
                    }
                }
            }
            sql = "select b.ID,a.URLPath as TaPath,b.URLPath as PrdPath from Lilly_TherapeuticAreas a inner join Lilly_Medicals b on a.ID=b.TID where a.Enabled=1";
            DataTable prd= LillyMedical.Utility.BusinessHelper.ExecuteQuery(sql);
            if (prd.Rows.Count > 0)
            {
                for (int i = 0; i < prd.Rows.Count; i++)
                {
                    string id= prd.Rows[i]["ID"].ToString();
                    string TaPath = prd.Rows[i]["TaPath"].ToString();
                    string PrdPath = prd.Rows[i]["PrdPath"].ToString();
                    string path = TaPath + "/" + PrdPath;
                    if (oldUrl == "/zh-cn/" + path)
                    {
                        Context.RewritePath("~/front/product.aspx?id=" + id);
                        return true; ;
                    }
                }
            }
            return false;
        }
        /// <summary>
        /// 判断是否是有效的QA Link
        /// </summary>
        /// <param name="OldUrl"></param>
        /// <param name="error_code"></param>
        /// <returns>false代表不是QA Link；true且error_code=""表示是有效的QA Link；true且error_code!=""表示无效的QA Link</returns>
        protected bool QALink(string OldUrl,out string error_code)
        {
            if (!OldUrl.StartsWith("/zh-cn/answer/"))
            {
                error_code = "";
                return false;
            }
            string VeevaID = OldUrl.Replace("/zh-cn/answer/", "");
            LillyMedical.Model.DBModel.Lilly_MedicalQA qa = LillyMedical.Utility.BusinessHelper.GetQAByVeevaID(VeevaID);
            if (qa!=null)
            {
                string FileName = qa.FilePath.Substring(qa.FilePath.LastIndexOf("\\") + 1);
                string newUrl = "~/files/qa_instance/" + FileName+"?from=self";
                string filePath = LillyMedical.Utility.LogFileHandler.GetWebRootPath() + @"\files\qa_instance\" + FileName;
                if (!File.Exists(qa.FilePath))
                {
                    error_code="2";
                }
                else
                {
                    if (qa.Status)
                    {
                        error_code = "";
                        Context.RewritePath(newUrl);
                    }
                    else
                    {
                        error_code = "1";
                    }
                }
            }
            else
            {
                error_code = "2";
            }
            return true;
        }

        protected void Application_AuthenticateRequest(object sender, EventArgs e)
        {

        }

        protected void Application_Error(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {

        }

        protected void Application_End(object sender, EventArgs e)
        {

        }
    }
}